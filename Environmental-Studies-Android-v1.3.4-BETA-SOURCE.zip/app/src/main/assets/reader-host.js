/* Security contract: one read-only sizing callback; no filesystem/network capability. */
(function(){
  'use strict';
  const host=window.AndroidHost;
  if(host)document.body.classList.add('native-host');
  let frame=0,lastHeight=-1,lastIndex=-2,pendingForce=false;
  const figureSelector='.naturalplate svg,.explainer svg,.visual svg,.ta-figure-card svg';
  window.reportHostHeight=function(force=false){
    pendingForce=pendingForce||force===true;
    cancelAnimationFrame(frame);
    frame=requestAnimationFrame(()=>{
      const forced=pendingForce;pendingForce=false;
      if(!host||typeof host.pageRendered!=='function')return;
      const page=document.getElementById('bookPage');
      const footer=document.getElementById('privacyFooter');
      const toc=document.getElementById('bookToc');
      const target=footer||page;if(!target)return;
      const bottom=target.getBoundingClientRect().bottom+window.scrollY;
      const tocBottom=toc?.classList.contains('open')?toc.getBoundingClientRect().bottom+window.scrollY:0;
      const height=Math.ceil(Math.max(bottom,tocBottom)+(parseFloat(getComputedStyle(document.body).paddingBottom)||0)+2);
      const index=footer?-1:(typeof bookIndex==='number'?bookIndex:0);
      if(Number.isFinite(height)&&height>0&&(forced||height!==lastHeight||index!==lastIndex)){
        lastHeight=height;lastIndex=index;host.pageRendered(index,height);
      }
    });
  };
  window.prepareVisualFocus=function(){
    const page=document.getElementById('bookPage');if(!page)return;
    page.querySelectorAll('.figure-branch').forEach(x=>x.classList.remove('figure-branch'));
    page.querySelectorAll(figureSelector).forEach(svg=>{
      svg.setAttribute('role','button');svg.setAttribute('tabindex','0');
      svg.setAttribute('aria-expanded',svg.parentElement.classList.contains('figure-expanded')?'true':'false');
      svg.setAttribute('aria-label','Enlarge or reduce figure / படத்தைப் பெரிதாக்கு அல்லது சிறிதாக்கு');
      let node=svg.parentElement;
      while(node&&node!==page){node.classList.add('figure-branch');node=node.parentElement;}
    });
    const button=document.getElementById('visualOnlyBtn');
    if(button){button.textContent=document.body.classList.contains('visual-focus')?'Full page / முழுப் பக்கம்':'Figures / படங்கள்';button.setAttribute('aria-pressed',document.body.classList.contains('visual-focus')?'true':'false');}
  };
  window.nativeToggleVisual=function(){
    const page=document.getElementById('bookPage');
    if(!page||![...page.querySelectorAll(figureSelector)].some(x=>x.getClientRects().length))return 'none';
    document.body.classList.toggle('visual-focus');window.prepareVisualFocus();window.reportHostHeight();
    return document.body.classList.contains('visual-focus')?'on':'off';
  };
  function toggleFigure(svg){
    if(!svg)return;
    const expanded=svg.parentElement.classList.toggle('figure-expanded');
    svg.setAttribute('aria-expanded',expanded?'true':'false');window.reportHostHeight();
  }
  document.addEventListener('click',event=>{
    if(event.target.closest?.('#visualOnlyBtn')){
      if(window.nativeToggleVisual()==='none')window.alert('No figures on this page / இந்தப் பக்கத்தில் படங்கள் இல்லை');
      return;
    }
    toggleFigure(event.target.closest?.(figureSelector));
  });
  document.addEventListener('keydown',event=>{
    if((event.key==='Enter'||event.key===' ')&&event.target.matches?.(figureSelector)){event.preventDefault();toggleFigure(event.target);}
    if(event.key==='Escape')window.closeExpandedFigure();
  });
  window.closeExpandedFigure=function(){
    const expanded=document.querySelector('.figure-expanded');if(!expanded)return false;
    expanded.classList.remove('figure-expanded');expanded.querySelector('svg')?.setAttribute('aria-expanded','false');window.reportHostHeight();return true;
  };
  window.addEventListener('load',()=>{window.prepareVisualFocus();window.reportHostHeight();});
  window.addEventListener('resize',()=>window.reportHostHeight());
  if(document.fonts)document.fonts.ready.then(()=>window.reportHostHeight());
  if(typeof ResizeObserver==='function'){
    const observer=new ResizeObserver(()=>window.reportHostHeight());
    for(const id of ['bookPage','privacyFooter','bookToc']){const node=document.getElementById(id);if(node)observer.observe(node);}
  }
})();
