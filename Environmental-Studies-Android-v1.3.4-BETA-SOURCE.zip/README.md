<!-- release-metadata:start -->
# Environmental Studies Android — v1.3.4 beta

versionName: `1.3.4` · versionCode: `10304` · reader pages: 81
<!-- release-metadata:end -->

Offline bilingual undergraduate textbook: 9 units, 46 lessons, 58 bilingual MCQs.
Package: `edu.gascnagercoil.environmentalsciences`. minSdk 24; target/compileSdk 36.

## Status

Compact-reader beta based on the exact source of the uploaded v1.3.3 APK. All nine unit files are byte-for-byte unchanged. English is followed by Tamil automatically; old single-language preferences migrate to this display. No language selection is needed.
Every book page has bottom navigation; the final page returns to the cover. Privacy has a bottom return link above the name/address footer.
Some technical simulator labels and bibliographic names remain in English. Translation equivalence and scientific/legal currency still require academic review.

Source and Chromium rendered-layout tests are provided. Chromium uses a mock native bridge, not an Android device. Handset acceptance remains required.
No new APK is included in this source ZIP. Build and handset acceptance must pass before distribution.

## Verify and build

Run these commands from the directory containing this README and `settings.gradle`:

```sh
python -m pip install -r tools/requirements.txt
python tools/sync_version.py --check
python tools/verify_content_integrity.py
python tools/test_verifier.py
node tools/test_reader.cjs
python -m pip install -r tools/requirements-layout.txt
python -m playwright install --with-deps chromium
python tools/test_layout.py
gradle --no-daemon clean lint test assembleDebug bundleRelease
```

Build prerequisites: JDK 17, Gradle 8.11.1, Android SDK platform 36, and access to configured dependency repositories.
The workflow belongs at repository-root `.github/workflows/environmental-sciences-android.yml`; all paths assume this project is at repository root. Do not nest this workflow inside a project subdirectory and expect GitHub to run it.

`app/build/outputs/apk/debug/app-debug.apk` is an installable debug-test build, not a production-signed release.
The release AAB has no signing credentials configured. Preserve your existing signing key for compatible upgrades; do not uninstall an existing app merely to bypass a signature mismatch without first considering loss of local preferences.

## Corrections

- Canonical verifier checks real catalog targets, every shipped asset hash, lesson language structure, SVG references, MCQ options and release metadata.
- Version metadata is generated from Gradle using `python tools/sync_version.py`; CI checks for drift.
- Cover navigation survives rewritten DOM IDs; Retry retries the failed destination; stale async results cannot replace a newer page.
- Unit-opening pathways are retained; navigation uses catalog keys/counts instead of fixed indices.
- Figures supports English and Tamil illustrations; tap or use Enter/Space to enlarge inline, then tap again to reduce. No viewport-sized lightbox inside the native scrolling WebView.
- Reader and Privacy use one bounded `AndroidHost.pageRendered(int,double)` sizing bridge. It exposes no data-access capability. Nonlocal resource loads are blocked.
- Android 16 system-bar insets and modern Back callbacks are handled explicitly.
- Name/address appears only in the Privacy footer, without a role title.

See `docs/audits/v1.3.4-reader-audit.md`, `docs/USER-MANUAL-v1.3.4-EN-TA.txt`, and `docs/NEXT-STEPS-v1.3.4.md`. Earlier audits/manuals are historical.

v1.3.4 uses one native toolbar row and one canonical `reader.css`, removing viewport-height unit openers, fixed-height Tamil diagrams, the native 520dp minimum and overlapping book CSS. Bottom controls follow content directly.

## Intentional content changes

25 detailed Tamil explanation additions complement the existing English explanations. The v1.2.4 generic three-level study prompts were retained where useful; they are not a substitute for subject-specific academic depth.
The current verifier uses minimum text floors as a regression check, not as proof of translation equivalence or teaching quality.

## Updating the integrity snapshot

After reviewing a deliberate source change, run `python tools/update_integrity.py`, then rerun all tests.
Never regenerate the snapshot simply to silence an unexplained failure. CI checks it and never regenerates it automatically.
Historical manifests remain as historical evidence, not the active release gate.
