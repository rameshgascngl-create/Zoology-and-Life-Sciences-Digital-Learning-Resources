"""Canonical structural/integrity gate. A pass is not an academic/device certification."""
from pathlib import Path
from bs4 import BeautifulSoup
import argparse,hashlib,json,re,sys
from sync_version import rendered_block,release_metadata
ROOT=Path(__file__).resolve().parents[1]
def verify(root=ROOT,check_hashes=True):
    a=root/'app/src/main/assets';errors=[]
    def check(ok,label):
        if not ok:errors.append(label)
    def soup(path):return BeautifulSoup(path.read_text(encoding='utf-8'),'html.parser')
    gradle=(root/'app/build.gradle').read_text()
    version=re.search(r"versionName\s+'([^']+)'",gradle).group(1)
    code=int(re.search(r'versionCode\s+(\d+)',gradle).group(1))
    index=soup(a/'index.html');catalog=json.loads((a/'book-catalog.json').read_text());pages=catalog.get('pages',[])
    check(index.title is not None and f'v{version}' in index.title.get_text(),'reader title version')
    check(catalog.get('version')==version,'catalog version');check(len(pages)==81,'81 pages')
    check([p.get('index') for p in pages]==list(range(len(pages))),'sequential catalog indices')
    check(len({p.get('key') for p in pages})==len(pages),'unique catalog keys')
    fronts=[x for x in index.main.find_all(recursive=False) if set(x.get('class',[]))&{'front','review','references'} and x.get('id')!='modularStatus']
    check(len(fronts)==8,'8 front/appendix pages')
    expected={};lessons=mcqs=0;question_names=set();docs=[(a/'index.html',index),(a/'privacy.html',soup(a/'privacy.html'))]
    files=sorted((a/'units').glob('unit-*.html'))
    check([p.name for p in files]==[f'unit-{n:02}.html' for n in range(1,10)],'exactly nine unit files')
    for unit,path in enumerate(files,1):
        doc=soup(path);docs.append((path,doc));container=doc.select_one('.unit')
        check(container is not None,f'unit root {unit}')
        if container is None:continue
        direct=container.find_all(recursive=False)
        check(any('note' in x.get('class',[]) for x in direct),f'unit {unit} pathway note')
        for kind,cls in [('opening','unithead'),('review','review'),('assessment','unit-mcq')]:
            matches=[x for x in direct if cls in x.get('class',[])]
            check(len(matches)==1,f'unit {unit} {kind}')
            expected[f'u{unit}:{kind}']=(unit,f'units/{path.name}','unit' if kind=='opening' else kind,matches[0].get('id') if matches else None)
        for lesson in doc.select('article.lesson'):
            lessons+=1;key=lesson.get('id');expected[key]=(unit,f'units/{path.name}','lesson',key)
            groups=lesson.find_all('section',class_='lesson-language',recursive=False)
            check([x.get('lang') for x in groups]==['en','ta'],f'English then Tamil {key}')
            if len(groups)!=2:continue
            en,ta=groups
            check(len(en.get_text(' ',strip=True).split())>=150,f'English text floor {key}')
            check(len(ta.get_text(' ',strip=True).split())>=80,f'Tamil depth {key}')
            check(not re.search('[\u0b80-\u0bff]',en.get_text()),f'Tamil leaked into English {key}')
            for selector in ['[data-pair-role="summary"]','[data-pair-role="key-terms"]','[data-pair-role="learning-outcome"]','[data-pair-role="think-apply"]']:
                check(en.select_one(selector) is not None and ta.select_one(selector) is not None,f'bilingual {selector} {key}')
            if en.select_one('.explain'):check(ta.select_one('.explain') is not None,f'Tamil explanation {key}')
        for q in doc.select('.mcq'):
            mcqs+=1;inputs=q.select('input[type="radio"]');labels=q.select('label')
            check(len(inputs)==4 and [x.get('value') for x in inputs]==['0','1','2','3'],f'MCQ choices {path.name}/{mcqs}')
            check(q.get('data-answer') in ['0','1','2','3'],f'MCQ answer {mcqs}')
            names={x.get('name') for x in inputs}
            check(len(names)==1 and None not in names and not names&question_names,f'MCQ radio group {mcqs}');question_names|=names
            check(q.select_one('p .en') is not None and q.select_one('p .ta') is not None,f'MCQ question languages {mcqs}')
            check(len(labels)==4 and all(x.select_one('.en') and x.select_one('.ta') for x in labels),f'MCQ option languages {mcqs}')
    check(lessons==46,'46 lessons');check(mcqs==58,'58 MCQs');catalog_units=set()
    for p in pages:
        key=p.get('key')
        if p.get('type')=='front':
            ordinal=p.get('frontOrdinal',0)
            check(isinstance(ordinal,int) and 1<=ordinal<=len(fronts),f'front ordinal {key}')
            if isinstance(ordinal,int) and 1<=ordinal<=len(fronts):
                source=fronts[ordinal-1];actual=source.get('id') or {2:'front-1',3:'front-2',6:'front-5',7:'front-6'}.get(ordinal)
                check(key==actual,f'front key resolves {key}')
        else:
            catalog_units.add(key);actual=(p.get('unit'),p.get('unitFile'),p.get('type'),p.get('sourceId'))
            check(expected.get(key)==actual,f'catalog source resolution {key}')
            rel=p.get('unitFile','')
            check(bool(re.fullmatch(r'units/unit-0[1-9]\.html',rel or '')) and (a/rel).is_file(),f'catalog unit file {key}')
    check(catalog_units==set(expected),'catalog covers every unit page exactly once')
    for path,doc in docs:
        ids=[x['id'] for x in doc.select('[id]')];check(len(ids)==len(set(ids)),f'unique DOM/SVG ids {path.name}')
        for svg in doc.select('svg'):
            local={x['id'] for x in svg.select('[id]')}
            for reference in re.findall(r'url\(#([^)]*)\)',str(svg)):check(reference in local,f'SVG reference {path.name}/{reference}')
        for node in doc.select('script[src],link[href],img[src],iframe[src]'):
            rel=node.get('src',node.get('href',''))
            check(not re.match(r'(?:https?:)?//',rel) and (path.parent/rel).is_file(),f'bundled resource {rel}')
    privacy=docs[1][1];footer=privacy.select('footer#privacyFooter')
    identity='R.Ramesh Department of Zoology Government Arts and Science College Nagercoil, Tamil Nadu'
    check(len(footer)==1 and footer[0].get_text(' ',strip=True)==identity,'Privacy-only name/address footer')
    for path,doc in docs:
        if path.name!='privacy.html':check('R.Ramesh' not in doc.get_text(),f'no attribution outside Privacy {path.name}')
    java=(root/'app/src/main/java/edu/gascnagercoil/environmentalsciences/MainActivity.java').read_text();host=(a/'reader-host.js').read_text();idx=str(index)
    check(len(re.findall(r'@JavascriptInterface\s+public void pageRendered\(int pageIndex, double cssHeight\)',java))==1 and java.count('@JavascriptInterface')==1,'single annotated sizing bridge')
    for token in ['Double.isFinite(cssHeight)','pageIndex >= pageCount','isLocalAsset(request.getUrl())','OnBackInvokedDispatcher','WindowInsets.Type.systemBars()','pageCount - 1']:
        check(token in java,'Android guard '+token)
    check('host.pageRendered(index,height)' in host and 'setContentHeight' not in str(privacy),'matching reader and Privacy bridge')
    check(index.select_one('script[src="reader-host.js"]') is not None and privacy.select_one('script[src="reader-host.js"]') is not None,'shared sizing script')
    manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
    check('android.permission.INTERNET' not in manifest,'no INTERNET permission')
    check('android:enableOnBackInvokedCallback="true"' in manifest,'modern Back enabled')
    check(index.select_one('[data-action="start-reading"]') is not None,'stable cover action')
    check('pathway.outerHTML' in idx,'opening includes pathway')
    css=(a/'reader.css').read_text()
    check(index.select_one('link[href="reader.css"]') is not None,'canonical reader stylesheet')
    check('pageNavigation(i)' in idx and 'data-page-target' in idx,'bottom page navigation')
    check(not index.select('[onclick*="setLang"]') and "setLang('both');" in idx,'no mandatory language choice')
    check('setFillViewport(false)' in java and 'dp(520)' not in java,'no native minimum page height')
    check(not re.search(r'\d(?:vh|dvh|svh)',css),'no viewport-height feedback in reader CSS')
    check(rendered_block(root) in (root/'README.md').read_text(),'README synchronized version block')
    check(json.loads((root/'verification/app-build-metadata.json').read_text())==release_metadata(root),'release metadata synchronized')
    if check_hashes:
        revision=json.loads((root/'verification/release-integrity.json').read_text())
        check(revision.get('version')==version and revision.get('versionCode')==code,'integrity manifest version')
        actual_files={str(p.relative_to(root)) for p in a.rglob('*') if p.is_file()}
        check(actual_files<=set(revision.get('sha256',{})),'every shipped asset is hashed')
        for name,digest in revision.get('sha256',{}).items():
            p=root/name;check(p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==digest,f'hash {name}')
    return errors
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=ROOT);args=parser.parse_args()
    try:errors=verify(args.root)
    except Exception as error:errors=[f'unreadable or malformed source: {error}']
    if errors:print('VERIFY FAIL: '+'; '.join(errors));sys.exit(1)
    print('VERIFY PASS: 9 units, 46 English-first/Tamil-second lessons, 58 bilingual MCQs, 81 resolved pages, SVG references, Privacy footer, bridge guards and release hashes. Device testing remains required.')
