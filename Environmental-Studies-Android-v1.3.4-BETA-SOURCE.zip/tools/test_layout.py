"""Chromium layout regression test. This is NOT Android/WebView handset acceptance."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
from threading import Thread
import argparse,json
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self,*args):pass

def frames(page):
    page.evaluate('()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))')

def start_server(directory):
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(QuietHandler,directory=str(directory)))
    Thread(target=server.serve_forever,daemon=True).start()
    return server,f'http://127.0.0.1:{server.server_port}'

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--baseline-assets',type=Path);args=parser.parse_args()
    output=ROOT/'verification/layout';output.mkdir(parents=True,exist_ok=True)
    server,url=start_server(ROOT/'app/src/main/assets')
    records=[];errors=[];metrics={}
    with sync_playwright() as p:
        browser=p.chromium.launch()
        for width,height in [(320,640),(412,800),(800,600)]:
            page=browser.new_page(viewport={'width':width,'height':height})
            page.on('pageerror',lambda error:errors.append(str(error)))
            # Model the native host's page-change scroll reset (not its touch handling).
            page.add_init_script("window.hostReports=[];let lastHostIndex;window.AndroidHost={pageRendered:(index,height)=>{window.hostReports.push({index,height});if(index!==lastHostIndex){window.scrollTo({top:0,behavior:'instant'});lastHostIndex=index;}}};localStorage.setItem('esLang','en');")
            page.goto(url+'/index.html');page.evaluate('window.readerReady')
            page.evaluate("showBookPage(0,'none')")
            count=page.evaluate('BOOK_CATALOG.length')
            for index in range(count):
                frames(page)
                m=page.evaluate('''()=>{
                  const book=document.getElementById('bookPage'),controls=book.querySelector('.page-controls');
                  const rect=controls.getBoundingClientRect(),before=controls.previousElementSibling.getBoundingClientRect();
                  return {index:bookIndex,key:BOOK_CATALOG[bookIndex].key,width:innerWidth,
                    height:book.getBoundingClientRect().height,overflow:document.documentElement.scrollWidth-innerWidth,
                    gap:rect.top-before.bottom,footerHeight:rect.height,next:Number(controls.querySelector('.page-next').dataset.pageTarget),
                    both:document.body.classList.contains('bothlang'),
                    hiddenLanguages:[...book.querySelectorAll('.lesson-language')].filter(x=>!x.getClientRects().length).length,
                    minimumFigures:[...book.querySelectorAll('svg')].map(x=>getComputedStyle(x).minHeight),
                    report:window.hostReports.at(-1),bottom:book.getBoundingClientRect().bottom+scrollY,
                    buttonHeights:[...controls.querySelectorAll('button')].map(x=>x.getBoundingClientRect().height)};
                }''')
                (output/'last-observed.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
                if m['overflow']>1 or m['gap']>36:
                    page.screenshot(path=str(output/'failure.png'),full_page=True)
                assert m['index']==index,m
                assert m['next']==(index+1 if index+1<count else 0),m
                assert m['overflow']<=1,m
                assert m['gap']<=36,m
                assert m['both'] and m['hiddenLanguages']==0,m
                assert all(x=='0px' for x in m['minimumFigures']),m
                assert min(m['buttonHeights'])>=48,m
                assert m['report']['index']==index and 0<=m['report']['height']-m['bottom']<=3,m
                records.append(m)
                if m['key'] in ['cover','u1:opening','u1l1','interactive'] and width in [320,412]:
                    page.screenshot(path=str(output/(str(width)+'-'+m['key'].replace(':','-')+'.png')),full_page=True)
                # Exercise the actual nested-label click handler, not just showBookPage().
                page.locator('#bookPage .page-next').click()
                expected=index+1 if index+1<count else 0
                page.wait_for_function('i=>bookIndex===i',arg=expected)
            assert page.evaluate('bookIndex')==0
            page.evaluate("navigateToKey('u1:opening')");frames(page)
            h1=page.locator('#bookPage').bounding_box()['height']
            page.set_viewport_size({'width':width,'height':2400});frames(page)
            h2=page.locator('#bookPage').bounding_box()['height']
            assert abs(h2-h1)<=1,('viewport feedback',width,h1,h2)
            metrics[str(width)]={'opener_at_short_viewport':h1,'opener_at_tall_viewport':h2}
            page.set_viewport_size({'width':width,'height':height})
            page.evaluate("navigateToKey('u1l1')");frames(page)
            svg=page.locator('.ta-figure-card svg').first
            if svg.count():
                svg.click();frames(page);assert svg.get_attribute('aria-expanded')=='true'
                assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
                svg.press('Enter');frames(page);assert svg.get_attribute('aria-expanded')=='false'
            assert page.evaluate('window.nativeToggleVisual()')=='on';frames(page)
            assert page.locator('.page-next').is_visible()
            page.locator('.page-next').click();page.wait_for_function("!document.body.classList.contains('visual-focus')")
            page.evaluate("navigateToKey('u1l1')")
            page.evaluate("document.documentElement.style.fontSize='200%'");frames(page)
            assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
            page.locator('.page-next').click();page.wait_for_function("BOOK_CATALOG[bookIndex].key==='u1l2'")
            page.goto(url+'/privacy.html');frames(page)
            assert page.locator('#privacyFooter').inner_text().startswith('R.Ramesh')
            page.locator('a.back').last.click();page.evaluate('window.readerReady')
            assert page.evaluate('BOOK_CATALOG[bookIndex].key')=='u1l2'
            page.close()
        if args.baseline_assets:
            old_server,old_url=start_server(args.baseline_assets)
            old=browser.new_page(viewport={'width':412,'height':800})
            old.add_init_script('window.AndroidHost={pageRendered(){}}')
            old.goto(old_url+'/index.html');old.evaluate('window.readerReady')
            old.evaluate("setLang('both');navigateToKey('u1:opening')");frames(old)
            metrics['baseline_opener_800']=old.locator('#bookPage').bounding_box()['height']
            old.screenshot(path=str(output/'baseline-unit-opening.png'),full_page=True)
            old.set_viewport_size({'width':412,'height':2400});frames(old)
            metrics['baseline_opener_2400']=old.locator('#bookPage').bounding_box()['height']
            old.close();old_server.shutdown()
        browser.close()
    server.shutdown()
    assert not errors,errors
    report={'scope':'Chromium + mock native bridge, not an Android device test','result':'PASS',
      'page_layouts':len(records),'widths':[320,412,800],'metrics':metrics,'pages':records,
      'checks':['81 real next-button destinations including end-to-cover','both languages visible despite old saved English preference',
      'no root horizontal overflow','compact footer gap','no SVG minimum heights','48px footer targets','bridge measures footer',
      'unit opener independent of viewport height','Tamil figure expansion','Figures mode then next','200% text','Privacy return and location restore']}
    (output/'layout-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('LAYOUT PASS:',len(records),'page layouts; metrics:',json.dumps(metrics))

if __name__=='__main__':main()
