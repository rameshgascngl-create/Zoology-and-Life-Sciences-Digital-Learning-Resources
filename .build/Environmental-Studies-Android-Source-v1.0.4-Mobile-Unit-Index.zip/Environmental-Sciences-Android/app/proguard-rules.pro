# No JavaScript bridge or reflection-based application API is used.
