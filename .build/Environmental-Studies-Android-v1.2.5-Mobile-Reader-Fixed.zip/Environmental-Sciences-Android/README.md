# Environmental Studies Android — v1.2.4

Offline bilingual undergraduate Environmental Studies textbook for Android.

- Package: `edu.gascnagercoil.environmentalsciences`
- versionName: `1.2.5`
- versionCode: `10205`
- minSdk 24; compileSdk/targetSdk 36
- 9 modular unit files, 46 lessons, 58 bilingual MCQs, 80 reader pages
- Local loading via `WebViewAssetLoader`; no INTERNET permission

## Content provenance

The v1.1.2 unit payloads are preserved under `verification/v1.1.2-units/`. v1.2.0 introduced the controlled bilingual content-quality revision. v1.2.1 builds on it with a Tamil terminology and prose-flow standardisation pass while preserving the verified scientific substance and assessment answer keys. The original v1.0.3 → v1.1.0 exact-extraction evidence remains preserved in `verification/unit-equivalence-manifest.json`.

The v1.2.5 hashes and v1.2.0 previous-release hashes are recorded in `verification/content-revision-manifest-v1.2.5.json`.

## Build

Use Java 17, Gradle 8.11.1 and Android SDK 36. CI should run verification before:

```bash
gradle --no-daemon clean lint test assembleDebug bundleRelease
```

Signing credentials are intentionally not included in the source tree.

## Tamil terminology and prose standard (v1.2.1)

Tamil terminology and sentence flow were re-audited against Tamil-medium higher-education/environmental sources, Tamil Nadu school science/geography usage, Tamil University terminology, and current Tamil government environmental usage. The preferred terminology is recorded in `verification/tamil-terminology-reference-v1.2.1.json`. This is an intentional language-quality revision; the previous v1.2.0 unit hashes remain recorded in the new revision manifest.

## Tamil reading-flow refinement (v1.2.3)

Tamil-only mode now presents Tamil unit pathways, learning outcomes, key terms, Tamil figures, review material and activities without avoidable English leakage. The house terminology is documented in `verification/tamil-terminology-reference-v1.2.3.json` and includes recognized textbook variants for student familiarity.

## Tamil terminology audit v1.2.3

Preferred teaching terminology now uses **காலநிலை மீள்திறன்** for climate resilience while retaining **காலநிலைத் தாங்குதிறன்** as an accepted Tamil Nadu policy variant. Ecosystem is standardized as **சூழல் மண்டலம்**, ecological pyramid as **சூழியல் பிரமிடம்**, and case study as **நிகழ்வாய்வு**.


## v1.2.5 mobile reader correction

This maintenance release fixes a device-confirmed Android WebView problem in book mode:
horizontal overflow, toolbar clipping and a page-turn state where only part of the next page remained visible.

On phone-sized viewports the toolbar now wraps within the viewport and the 3-D `rotateY`
page animation is replaced by a contained fade transition. The first/restored page opens
without a turn animation. Educational unit content is unchanged from v1.2.4.
