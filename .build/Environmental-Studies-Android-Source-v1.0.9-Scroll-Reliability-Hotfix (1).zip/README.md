# Environmental Studies Android

Offline Android wrapper for the frozen Environmental Studies EN/TA v12.2 content baseline.

- Package: `edu.gascnagercoil.environmentalsciences`
- versionName: 1.0.9
- versionCode: 10009
- Version-code convention: `major*10000 + minor*100 + patch`
- minSdk: 24
- compileSdk / targetSdk: 36
- Runtime content: bundled locally through AndroidX `WebViewAssetLoader`
- Permissions: none requested
- Network runtime dependency: none
- Launcher label: English + Tamil locale resource
- Launcher icon: adaptive + monochrome themed-icon resource

## Build

The repository CI pins **Gradle 8.11.1** using `gradle/actions/setup-gradle`. For a local clone, install Gradle 8.11.1 (or open the project in a compatible Android Studio) and run:

```bash
gradle --no-daemon clean lint test assembleDebug bundleRelease
```

The source archive intentionally does not embed signing credentials. `bundleRelease` is therefore not a Play-submittable signed production bundle until the developer configures the real Google Play upload key in a secure local/CI secret store. Never commit the keystore or passwords to source control.

## Attribution

APK-generated-by attribution is displayed in the textbook footer:

R.Ramesh  
Department of Zoology  
Government Arts and Science College, Nagercoil, Tamil Nadu


## v1.0.5 — True Mobile Pagination Edition
- Navigation model: Unit → Chapter → screen-sized semantic pages.
- Preserves all 46 lessons, bilingual English/Tamil content, diagrams and unit assessments.
- Unit index and chapter index are separate reader levels.
- Long lessons are divided at semantic block boundaries rather than arbitrary character positions.
- MCQ selections persist while paging; each question can be checked and a unit score can be calculated.
- Mobile tables become stacked labelled cards to eliminate horizontal overflow.
- The original educational source remains embedded in `index.html`; the reader is a presentation layer over that source.



## v1.0.7 Release-Candidate Cleanup

- AndroidX WebKit updated from 1.14.0 to 1.17.0.
- Removed explicit `android:screenOrientation="unspecified"` so Android manages orientation/form factors natively.
- Removed unused legacy `res/drawable/ic_launcher.xml`.
- v1.0.6 educational HTML, bilingual reader, pagination logic, diagrams, assessments and regression-test content are unchanged.

## v1.0.6 QA/Fit Edition
Measured viewport pagination, language/resize repagination, persistent MCQ state, chapter-local progress, complete review coverage, comparison cards, legacy-reader removal and static mobile regression tests.


## v1.0.9 WebView Renderer Recovery

- Added `WebViewClient.onRenderProcessGone()` recovery handling.
- A terminated WebView renderer is removed and destroyed safely, then the Activity is recreated.
- Educational HTML and v1.0.6 reader/pagination content are unchanged byte-for-byte.
- Intended to eliminate the final `MissingOnRenderProcessGone` lint warning.


## v1.0.9 Scroll Reliability Hotfix
Measured viewport pagination remains enabled. Vertical scrolling is now permitted only as a safety fallback inside the reading pane and unit/chapter indexes so no content can be clipped on real Android WebView sizes, Tamil mode, large accessibility fonts, or tall figures. Horizontal overflow remains suppressed.
