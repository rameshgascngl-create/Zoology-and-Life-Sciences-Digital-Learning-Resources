/* Ornamental Fish App 2.4.1 responsive hotfix */
(function () {
  const VERSION = "2.4.3";
  const $ = (s) => document.querySelector(s);
  const main = () => $("#main");
  const state = {
    ta: localStorage.getItem("of_lang") === "ta",
    tab: "home",
    fish: null,
    bi: Number(localStorage.getItem("of_page") || 0),
    qi: Number(localStorage.getItem("of_qi") || 0),
    picked: null,
    score: Number(localStorage.getItem("of_score") || 0),
    marks: JSON.parse(localStorage.getItem("of_marks") || "[]"),
    answered: JSON.parse(localStorage.getItem("of_answered") || "{}"),
    quizView: "ask",
    q: "",
    filter: "all"
  };
  let SPECIES = [], BOOK = [], QUIZ = [], LABS = [];
  const IMG = "fish_atlas/";

  let currentLayout = "compact";

  function viewportWidth() {
    const vv = window.visualViewport && Number(window.visualViewport.width);
    return (vv && vv > 0) ? vv : window.innerWidth;
  }

  function physicalShortSideCss() {
    const sw = Number(window.screen && window.screen.width) || 0;
    const sh = Number(window.screen && window.screen.height) || 0;
    return (sw > 0 && sh > 0) ? Math.min(sw, sh) : 0;
  }

  function classifyLayout() {
    const vw = viewportWidth();
    const shortSide = physicalShortSideCss();
    const mobileUA = /Android.*Mobile|iPhone|iPod|Windows Phone/i.test(navigator.userAgent || "");

    // A normal phone must stay in compact mode even if WebView wide-viewport
    // scaling reports a large layout viewport. Tablets/foldables require a
    // genuine short side of at least 600 CSS px.
    if (mobileUA && shortSide && shortSide < 600) return "compact";
    if (shortSide && shortSide < 600) return "compact";
    if (vw < 600) return "compact";
    if (vw >= 840) return "expanded";
    return "medium";
  }

  function applyLayout(forceRender) {
    const next = classifyLayout();
    const changed = next !== currentLayout;
    currentLayout = next;
    document.documentElement.dataset.layout = next;
    if (changed && forceRender && (state.tab === "atlas" || state.tab === "book")) render();
  }

  function wide() { return currentLayout === "expanded"; }
  function t(en, ta) { return state.ta ? ta : en; }
  function save() {
    localStorage.setItem("of_lang", state.ta ? "ta" : "en");
    localStorage.setItem("of_page", String(state.bi));
    localStorage.setItem("of_score", String(state.score));
    localStorage.setItem("of_qi", String(state.qi));
    localStorage.setItem("of_marks", JSON.stringify(state.marks));
    localStorage.setItem("of_answered", JSON.stringify(state.answered));
  }
  function applyLang() {
    document.documentElement.lang = state.ta ? "ta" : "en";
    const btn = $("#langBtn");
    if (btn) {
      btn.textContent = state.ta ? "EN" : "தமிழ்";
      btn.setAttribute("aria-label", state.ta ? "Switch to English" : "தமிழுக்கு மாற்று");
      btn.title = state.ta ? "Switch to English" : "தமிழுக்கு மாற்று";
    }
    const title = $("#appTitle");
    const sub = $("#appSubtitle");
    if (title) title.textContent = t("Ornamental Fish Science", "அலங்கார மீன் அறிவியல்");
    if (sub) sub.textContent = t("Ornamental Fish Farming · v" + VERSION, "அலங்கார மீன் வளர்ப்பு · v" + VERSION);
    document.querySelectorAll(".nav-label").forEach((n) => {
      n.textContent = state.ta ? n.dataset.ta : n.dataset.en;
    });
  }
  function setTab(tab) {
    state.tab = tab;
    if (tab !== "atlas") state.fish = null;
    document.querySelectorAll("nav.tabs button").forEach((b) => {
      b.setAttribute("aria-current", b.dataset.tab === tab ? "page" : "false");
    });
    render();
  }
  function plate(s, cls) {
    if (!s.img) {
      return `<div class="missing" role="img" aria-label="${state.ta ? s.alt_ta : s.alt_en}">${t("Verified image not yet available","சரிபார்க்கப்பட்ட படம் இன்னும் கிடைக்கவில்லை")}</div>`;
    }
    return `<img class="${cls || ""}" src="${IMG}${s.img}" alt="${state.ta ? s.alt_ta : s.alt_en}" loading="lazy">`;
  }
  function val(s, enKey, taKey) { return state.ta ? (s[taKey] || s[enKey]) : s[enKey]; }

  function home() {
    const tiles = [
      ["atlas", t("Explore species","இனங்களை ஆயுங்கள்"), t("Searchable accounts","தேடும் விவரணம்")],
      ["india", t("Ornamental fishes of India","இந்திய அலங்கார மீன்கள்"), t("Native and endemic notes","தாயகக் குறிப்பு")],
      ["book", t("Continue learning","பாடத்தைத் தொடருங்கள்"), t("Textbook pages","பாடநூல் பக்கங்கள்")],
      ["science", t("Aquarium science","அகவாரி அறிவியல்"), t("Water, cycle, filters","நீர், சுழற்சி, வடிகட்டி")],
      ["breed", t("Breeding","இனப்பெருக்கம்"), t("Egg-layers and livebearers","முட்டையிடுபவை, உள்பொரி")],
      ["health", t("Fish health","மீன் நலம்"), t("Biosecurity, no drug recipes","உயிர்ப் பாதுகாப்பு")],
      ["lab", t("Practical laboratory","செய்முறை ஆய்வகம்"), t("Aim and precautions","நோக்கமும் முன்னெச்சரிக்கையும்")],
      ["quiz", t("Quiz","வினா"), t("Reviewed questions with explanations","விளக்கங்களுடன் மீள்பார்வை வினாக்கள்")],
      ["tools", t("Tools","கருவிகள்"), t("Water and farm calculators","நீர் மற்றும் பண்ணைக் கணக்கிகள்")],
      ["privacy", t("Privacy Policy","தனியுரிமைக் கொள்கை"), t("View the app privacy policy","செயலியின் தனியுரிமைக் கொள்கையைப் பார்க்க")],
      ["marks", t("Bookmarks","சேமிப்புகள்"), String(state.marks.length)]
    ];
    const gallery = SPECIES.map((s) => {
      const pic = s.img
        ? `<img class="thumb" src="${IMG}${s.img}" alt="${state.ta ? s.alt_ta : s.alt_en}" loading="lazy">`
        : "";
      return `<button type="button" class="tile" data-fish="${s.id}" aria-label="${state.ta ? s.ta : s.en}"><div class="row">${pic}<div><strong>${state.ta ? s.ta : s.en}</strong><div><i>${s.sci}</i></div></div></div></button>`;
    }).join("");
    return `
      <h2>${t("Ornamental fishes","அலங்கார மீன்கள்")}</h2>
      <p class="lead">${t("Tap a fish to open its account. Lessons are under Learn.","விவரணத்துக்கு மீனைத் தொடவும். பாடங்கள் Learn-இல்.")}</p>
      <div class="grid home">${gallery}</div>
      <h3>${t("Units","அலகுகள்")}</h3>
      <div class="grid home">${tiles.map(([go, title, sub]) =>
        `<button type="button" class="tile" data-go="${go}"><h3>${title}</h3><p class="muted">${sub || ""}</p></button>`).join("")}</div>
      <p class="home-credit">R.Ramesh<br>Department of Zoology<br>Government Arts and Science College<br>Nagercoil, Tamil Nadu</p>`;
  }

  function matches(s) {
    const q = state.q.trim().toLowerCase();
    if (state.filter === "indigenous" && s.origin !== "indigenous") return false;
    if (state.filter === "exotic" && s.origin !== "exotic") return false;
    if (state.filter === "freshwater" && s.habitat !== "freshwater") return false;
    if (state.filter === "brackish" && s.habitat !== "brackish") return false;
    if (state.filter === "marine" && s.habitat !== "marine") return false;
    if (state.filter === "livebearer" && s.breed_type !== "livebearer") return false;
    if (state.filter === "egg-layer" && s.breed_type !== "egg-layer") return false;
    if (state.filter === "peaceful" && s.temper_class !== "peaceful") return false;
    if (state.filter === "active" && !/active|labyrinth|cichlid/.test(s.temper_class || "")) return false;
    if (state.filter === "conservation" && !/endemic|threatened|Endangered|Red List/i.test((s.iucn || "") + (s.status_in || ""))) return false;
    if (!q) return true;
    const bag = [s.en, s.ta, s.sci, s.synonym, s.family, s.native, s.ta_native, s.status_in, s.form].join(" ").toLowerCase();
    return bag.indexOf(q) >= 0;
  }

  function card(s) {
    const thumb = s.img
      ? `<img class="thumb" src="${IMG}${s.img}" alt="${state.ta ? s.alt_ta : s.alt_en}" loading="lazy">`
      : `<div class="missing" style="width:92px;height:70px;flex:none;font-size:.65rem">${t("No image","படம் இல்லை")}</div>`;
    return `<button type="button" class="tile" data-fish="${s.id}" aria-label="${state.ta ? s.ta : s.en}, ${s.sci}">
      <div class="row">${thumb}<div><strong>${state.ta ? s.ta : s.en}</strong>
      <div class="gold"><i>${s.sci}</i></div>
      <span class="chip">${s.origin}</span><span class="chip">${s.habitat}</span></div></div></button>`;
  }

  function atlasList() {
    const list = SPECIES.filter(matches);
    const filters = [
      ["all", t("All","அனைத்தும்")],
      ["indigenous", t("Indian native","தாயக")],
      ["exotic", t("Exotic","வெளிநாட்டு")],
      ["freshwater", t("Freshwater","நன்னீர்")],
      ["brackish", t("Brackish","உவர்")],
      ["marine", t("Marine","கடல்")],
      ["livebearer", t("Livebearer","உள்பொரி")],
      ["egg-layer", t("Egg-layer","முட்டையிடுபவை")],
      ["peaceful", t("Peaceful","அமைதி")],
      ["active", t("Active / territorial","சுறுசுறுப்பு")],
      ["conservation", t("Conservation note","பாதுகாப்பு")]
    ];
    return `<label class="muted" for="q">${t("Search names, family or region","பெயர், குடும்பம், பரவல்")}</label>
      <input id="q" class="search" type="search" value="${state.q.replace(/"/g,"&quot;")}">
      <div class="filters">${filters.map(([id, lab]) =>
        `<button type="button" data-filter="${id}" aria-pressed="${state.filter===id}">${lab}</button>`).join("")}</div>
      <p class="muted">${list.length} / ${SPECIES.length}</p>
      <div class="species-grid">${list.map(card).join("") || `<p class="muted">${t("No matches.","பொருத்தம் இல்லை.")}</p>`}</div>`;
  }

  function block(title, rows) {
    return `<section class="tile section"><h3>${title}</h3><table>${rows.map((r) => `<tr><th>${r[0]}</th><td>${r[1]}</td></tr>`).join("")}</table></section>`;
  }

  function detail(s) {
    const sci = s.sci.split("(")[0].trim();
    const form = s.form || "";
    const saved = state.marks.includes(s.id);
    const idRows = [
      [t("Scientific name","அறிவியல் பெயர்"), `<i>${sci}</i>`],
      form ? [t("Trade / ornamental form","வணிக / அலங்கார வடிவம்"), form] : null,
      s.synonym ? [t("Legacy / trade synonym","பழைய / வணிகப் பெயர்"), `<i>${s.synonym}</i>`] : null,
      [t("Family / order","குடும்பம் / வரிசை"), `${s.family} / ${s.order}`]
    ].filter(Boolean);
    const dist = [
      [t("Native range","தாயகப் பரவல்"), val(s,"native","ta_native")],
      [t("Status in India","இந்திய நிலை"), val(s,"status_in","ta_status_in")],
      [t("Habitat class","வாழிட வகை"), s.habitat]
    ];
    const water = [
      [t("Holding temperature","வளர்ப்பு வெப்பம்"), val(s,"temp_hold_c","ta_temp_hold_c")],
      [t("Breeding temperature","இனப்பெருக்க வெப்பம்"), val(s,"temp_breed_c","ta_temp_breed_c")],
      ["pH", val(s,"ph","ta_ph")],
      ["GH / KH", val(s,"gh_kh","ta_gh_kh")],
      [t("Salinity","உவர்நிலை"), val(s,"salinity","ta_salinity")]
    ];
    const beh = [
      [t("Temperament","தன்மை"), val(s,"temper","ta_temper")],
      [t("Minimum system","குறைந்த அமைப்பு"), val(s,"tank_min_l","ta_tank_min_l")],
      [t("Group","கூட்டம்"), val(s,"group","ta_group")],
      [t("Compatibility","இணை வாழ்தல்"), val(s,"compat","ta_compat")]
    ];
    const html = `<p><button type="button" class="go" data-go="atlas">← ${t("Atlas","அட்டவணை")}</button>
      <button type="button" class="go" data-mark="${s.id}">${saved ? "★" : "☆"} ${t("Bookmark","புத்தக்குறி")}</button></p>
      ${plate(s, "hero")}<p class="ai">${s.img_note || ""}</p>
      <h2>${state.ta ? s.ta : s.en}</h2>
      <div class="cards2">
      ${block(t("Identity","அடையாளம்"), idRows)}
      ${block(t("Distribution & habitat","பரவலும் வாழிடமும்"), dist)}
      ${block(t("Water requirements","நீர் தேவை"), water)}
      ${block(t("Behaviour & compatibility","நடத்தையும் இணை வாழ்தலும்"), beh)}
      ${block(t("Feeding","உணவு"), [[t("Diet","உணவு"), val(s,"diet","ta_diet")]])}
      ${block(t("Breeding","இனப்பெருக்கம்"), [
        [t("Mode","முறை"), val(s,"breed","ta_breed")],
        [t("Sex","பாலினம்"), val(s,"sex","ta_sex")],
        [t("Fry","குஞ்சு"), val(s,"fry","ta_fry")]
      ])}
      ${block(t("Health & quarantine","நலமும் தனிமையும்"), [
        [t("Health notes","நோய் குறிப்பு"), val(s,"disease","ta_disease")],
        [t("Quarantine","தனிமை"), val(s,"quarantine","ta_quarantine")]
      ])}
      ${block(t("Conservation","பாதுகாப்பு"), [[t("Note","குறிப்பு"), val(s,"iucn","ta_iucn")]])}
      ${block(t("References","ஆதாரம்"), [[t("Sources","மூலம்"), s.refs]])}
      </div>`;
    return html;
  }

  function atlas() {
    if (wide()) {
      if (!state.fish) state.fish = SPECIES.find(matches) || SPECIES[0];
      return `<div class="split"><div class="pane">${atlasList()}</div><div>${state.fish ? detail(state.fish) : ""}</div></div>`;
    }
    return state.fish ? detail(state.fish) : `<h2>${t("Species accounts","இன விவரணம்")}</h2>${atlasList()}`;
  }

  function marks() {
    const saved = SPECIES.filter((s) => state.marks.includes(s.id));
    return `<h2>${t("My Bookmarks","எனது சேமிப்புகள்")}</h2>
      ${saved.length ? saved.map(card).join("") : `<p class="muted">${t("Nothing saved yet.","இன்னும் சேமிப்பு இல்லை.")}</p>`}
      ${saved.length ? `<p><button type="button" class="go" data-clearmarks="1">${t("Clear all bookmarks","அனைத்துச் சேமிப்பையும் அழி")}</button></p>` : ""}`;
  }

  function bookPane() {
    const groups = {};
    BOOK.forEach((p, i) => { (groups[p.ch] = groups[p.ch] || []).push({ p, i }); });
    return `<div class="toc">${Object.keys(groups).map((ch) =>
      `<p class="kicker">${ch}</p>` + groups[ch].map(({ p, i }) =>
        `<button type="button" data-page="${i}" aria-current="${i===state.bi}">${state.ta ? p.ta_t : p.en_t}</button>`
      ).join("")
    ).join("")}</div>`;
  }
  function bookPage() {
    const P = BOOK[state.bi];
    if (!P) return "";
    return `<p class="page-no">${t("PAGE","பக்கம்")} ${state.bi + 1} / ${BOOK.length} · v${VERSION}</p>
      <article class="page"><p class="kicker">${P.ch}</p><h2>${state.ta ? P.ta_t : P.en_t}</h2>${state.ta ? P.ta : P.en}</article>
      <div class="pager">
        <button type="button" data-turn="-1" ${state.bi===0?"disabled":""}>← ${t("Prev","முன்")}</button>
        <button type="button" data-turn="1" ${state.bi===BOOK.length-1?"disabled":""}>${t("Next","அடுத்தது")} →</button>
      </div>`;
  }
  function book() {
    state.bi = Math.max(0, Math.min(BOOK.length - 1, state.bi));
    if (wide()) return `<div class="split"><div class="pane">${bookPane()}</div><div>${bookPage()}</div></div>`;
    return bookPage();
  }

  function lab() {
    return `<h2>${t("Practical laboratory","செய்முறை ஆய்வகம்")}</h2>
      <div class="grid labs">${LABS.map((L) => `<article class="tile"><h3>${state.ta ? L.ta_t : L.en_t}</h3>${state.ta ? L.ta : L.en}</article>`).join("")}</div>`;
  }

  function quiz() {
    const total = QUIZ.length;
    const nAns = Object.keys(state.answered).length;
    if (state.quizView === "result") {
      const wrong = [];
      QUIZ.forEach((q, i) => {
        const picked = state.answered["q" + i];
        if (picked === undefined || picked !== q.a) wrong.push({ i, q, picked });
      });
      const pct = total ? Math.round((state.score / total) * 100) : 0;
      return `<p class="kicker">${t("Quiz result","வினா முடிவு")}</p>
        <h2>${t("Score","மதிப்பெண்")} ${state.score} / ${total} (${pct}%)</h2>
        <p class="muted">${t("Answered","விடையளித்தவை")} ${nAns} / ${total}</p>
        ${wrong.length ? `<h3>${t("Review","மீள்பார்வை")}</h3>` + wrong.map(({ i, q, picked }) =>
          `<article class="tile"><p><strong>${i + 1}.</strong> ${state.ta ? q.qt : q.q}</p>
           <p class="muted">${t("Your answer","உங்கள் விடை")}: ${picked === undefined ? "—" : (state.ta ? q.ot : q.o)[picked]}</p>
           <p>${t("Correct","சரி")}: ${(state.ta ? q.ot : q.o)[q.a]}</p>
           <p class="muted">${state.ta ? q.et : q.e}</p></article>`
        ).join("") : `<p>${t("All answers correct.","அனைத்து விடைகளும் சரி.")}</p>`}
        <p>
          <button type="button" class="go" data-quizact="restart">${t("Restart quiz","மீண்டும் தொடங்கு")}</button>
          <button type="button" class="go" data-quizact="continue">${t("Continue unanswered","விடாத வினா")}</button>
        </p>`;
    }
    const q = QUIZ[state.qi];
    if (!q) return `<p>${t("No quiz.","வினா இல்லை.")}</p>`;
    const id = "q" + state.qi;
    const done = Object.prototype.hasOwnProperty.call(state.answered, id);
    const picked = done ? state.answered[id] : state.picked;
    const opts = state.ta ? q.ot : q.o;
    const pct = Math.round((nAns / total) * 100);
    return `<p class="kicker">${q.type.toUpperCase()} ${state.qi + 1}/${total}</p>
      <div class="progress" aria-hidden="true"><span style="width:${pct}%"></span></div>
      <h2>${state.ta ? q.qt : q.q}</h2>
      <p class="muted">${t("Score","மதிப்பெண்")} ${state.score} / ${nAns}</p>
      ${opts.map((o, i) => {
        let cls = "opt";
        if (picked !== null && picked !== undefined) {
          if (i === q.a) cls += " ok";
          else if (i === picked) cls += " bad";
        }
        return `<button type="button" class="${cls}" data-ans="${i}" ${done ? "disabled" : ""}>${o}</button>`;
      }).join("")}
      ${picked === null || picked === undefined ? "" : `<p class="muted">${state.ta ? q.et : q.e}</p>
        <button type="button" class="go" data-nextq="1">${state.qi < total - 1 ? t("Next question","அடுத்த வினா") : t("See result","முடிவு")}</button>`}
      <p>
        <button type="button" class="go" data-quizact="continue">${t("Continue quiz","தொடர்")}</button>
        <button type="button" class="go" data-quizact="result">${t("Results","முடிவுகள்")}</button>
        <button type="button" class="go" data-quizact="restart">${t("Restart quiz","மீண்டும் தொடங்கு")}</button>
        <button type="button" class="go" data-quizact="reset">${t("Reset progress","முன்னேற்றத்தைச் சுழி")}</button>
      </p>`;
  }

  function tools() {
    return `<div class="grid tools">
      <article class="tile"><h3>${t("Rectangular volume","செவ்வகக் கொள்ளளவு")}</h3>
      <label for="vl">${t("Length cm","நீளம் செ.மீ.")}</label><input id="vl" type="number" min="0" value="90">
      <label for="vw">${t("Width cm","அகலம் செ.மீ.")}</label><input id="vw" type="number" min="0" value="45">
      <label for="vh">${t("Water height cm","நீர் உயரம் செ.மீ.")}</label><input id="vh" type="number" min="0" value="40">
      <button type="button" class="go" data-calc="vol">${t("Calculate","கணக்கிடு")}</button>
      <p id="vout"></p></article>
      <article class="tile"><h3>${t("Unionised NH₃ from TAN","TAN-இலிருந்து NH₃")}</h3>
      <p class="muted">${t("TAN input is mg/L as nitrogen (NH₃-N + NH₄⁺-N). Output is the unionised fraction and NH₃-N mg/L = TAN × fraction. Formula after Emerson et al. 1975 (J. Fish. Res. Board Can.). Not a certified laboratory result.","TAN உள்ளீடு நைட்ரஜனாக mg/L. வெளியீடு அயனியாகாத விகிதமும் NH₃-N mg/L-உம். Emerson மற்றும் பலர் 1975. ஆய்வகச் சான்று அல்ல.")}</p>
      <label for="tan">TAN (mg/L as N)</label><input id="tan" type="number" min="0" max="50" value="0.5" step="0.01">
      <label for="ph">pH</label><input id="ph" type="number" min="6" max="10" value="8.0" step="0.1">
      <label for="tc">T °C</label><input id="tc" type="number" min="5" max="40" value="28" step="0.1">
      <button type="button" class="go" data-calc="tan">${t("Interpret","விளக்கு")}</button>
      <p id="tout"></p></article>
      <article class="tile"><h3>${t("Water-change volume","நீர் மாற்ற அளவு")}</h3>
      <label for="tl">${t("Aquarium volume L","தொட்டி லிட்டர்")}</label><input id="tl" type="number" min="0" value="100">
      <label for="pc">${t("Change %","மாற்ற %")}</label><input id="pc" type="number" min="0" max="100" value="30">
      <button type="button" class="go" data-calc="wc">${t("Calculate","கணக்கிடு")}</button>
      <p id="wout"></p></article>
      <article class="tile"><h3>${t("Farm economics (teaching model)","பண்ணைப் பொருளாதாரம் (வகுப்பு மாதிரி)")}</h3>
      <label for="cap">${t("CAPEX ₹","மூலதனச் செலவு ₹")}</label><input id="cap" type="number" min="0" value="80000">
      <label for="life">${t("Asset life years","சொத்து ஆயுள் ஆண்டு")}</label><input id="life" type="number" min="1" value="5">
      <label for="opex">${t("Annual OPEX ₹","ஆண்டு இயக்கச் செலவு ₹")}</label><input id="opex" type="number" min="0" value="40000">
      <label for="prod">${t("Annual production (units)","ஆண்டு உற்பத்தி")}</label><input id="prod" type="number" min="0" value="2000">
      <label for="price">${t("Selling price ₹ / unit","விற்பனை விலை ₹")}</label><input id="price" type="number" min="0" value="80">
      <label for="mort">${t("Mortality / loss %","இறப்பு / இழப்பு %")}</label><input id="mort" type="number" min="0" max="100" value="10">
      <button type="button" class="go" data-calc="eco">${t("Calculate","கணக்கிடு")}</button>
      <p id="eout"></p>
      <p class="muted">${t("Straight-line depreciation; no discounting. Teaching model only.","எளிய தேய்மானம். வகுப்பு மாதிரி மட்டும்.")}</p></article>
    </div>`;
  }

  function render() {
    applyLang();
    const m = main();
    if (state.tab === "home") m.innerHTML = home();
    else if (state.tab === "atlas" || state.tab === "india") m.innerHTML = atlas();
    else if (state.tab === "book" || state.tab === "science" || state.tab === "breed" || state.tab === "health") m.innerHTML = book();
    else if (state.tab === "lab") m.innerHTML = lab();
    else if (state.tab === "quiz") m.innerHTML = quiz();
    else if (state.tab === "marks") m.innerHTML = marks();
    else m.innerHTML = tools();
    if (state.tab === "india") { state.filter = "indigenous"; }
    if (state.tab === "science") state.bi = BOOK.findIndex((p) => p.ch === "IV") || state.bi;
    const box = $("#q");
    if (box) {
      box.addEventListener("input", () => {
        state.q = box.value;
        const keep = box.selectionStart;
        render();
        const n = $("#q");
        if (n) { n.focus(); try { n.setSelectionRange(keep, keep); } catch (e) {} }
      });
    }
  }

  function onClick(ev) {
    const el = ev.target.closest("[data-go],[data-fish],[data-turn],[data-ans],[data-nextq],[data-calc],[data-mark],[data-filter],[data-quizact],[data-clearmarks],[data-page],#langBtn");
    if (!el) return;
    if (el.id === "langBtn") { state.ta = !state.ta; save(); render(); return; }
    if (el.dataset.filter) { state.filter = el.dataset.filter; render(); return; }
    if (el.dataset.page) { state.bi = Number(el.dataset.page); save(); render(); return; }
    if (el.dataset.go) {
      if (el.dataset.go === "privacy") { window.location.href = "privacy-policy.html"; return; }
      if (el.dataset.go === "india") { state.tab = "atlas"; state.filter = "indigenous"; state.fish = null; render(); return; }
      if (el.dataset.go === "science") { state.tab = "book"; state.bi = Math.max(0, BOOK.findIndex((p) => p.id === "iv1")); save(); render(); return; }
      if (el.dataset.go === "breed") { state.tab = "book"; state.bi = Math.max(0, BOOK.findIndex((p) => p.id === "ii1")); save(); render(); return; }
      if (el.dataset.go === "health") { state.tab = "book"; state.bi = Math.max(0, BOOK.findIndex((p) => p.id === "iv6")); save(); render(); return; }
      setTab(el.dataset.go); return;
    }
    if (el.dataset.fish) { state.fish = SPECIES.find((s) => s.id === el.dataset.fish); state.tab = "atlas"; render(); return; }
    if (el.dataset.mark) {
      const id = el.dataset.mark;
      state.marks = state.marks.includes(id) ? state.marks.filter((x) => x !== id) : state.marks.concat(id);
      save(); render(); return;
    }
    if (el.dataset.clearmarks) { state.marks = []; save(); render(); return; }
    if (el.dataset.turn) { state.bi += Number(el.dataset.turn); save(); render(); return; }
    if (el.dataset.quizact === "restart" || el.dataset.quizact === "reset") {
      state.qi = 0; state.score = 0; state.picked = null; state.answered = {}; save(); render(); return;
    }
    if (el.dataset.quizact === "continue") {
      let next = state.qi;
      for (let step = 1; step <= QUIZ.length; step += 1) {
        const candidate = (state.qi + step) % QUIZ.length;
        if (!Object.prototype.hasOwnProperty.call(state.answered, "q" + candidate)) { next = candidate; break; }
      }
      state.qi = next; state.picked = null; save(); render(); return;
    }
    if (el.dataset.ans !== undefined) {
      const id = "q" + state.qi;
      if (Object.prototype.hasOwnProperty.call(state.answered, id)) return;
      const ans = Number(el.dataset.ans);
      state.picked = ans;
      state.answered[id] = ans;
      if (ans === QUIZ[state.qi].a) state.score += 1;
      save(); render(); return;
    }
    if (el.dataset.nextq) {
      if (state.qi < QUIZ.length - 1) { state.qi += 1; state.picked = null; save(); }
      else { state.quizView = "result"; }
      render(); return;
    }
    runCalc(el.dataset.calc);
  }

  function runCalc(kind) {
    const err = (id, msg) => { const n = document.getElementById(id); if (n) { n.className = "err"; n.textContent = msg; } };
    const ok = (id, msg) => { const n = document.getElementById(id); if (n) { n.className = ""; n.textContent = msg; } };
    if (kind === "vol") {
      const L = +$("#vl").value, W = +$("#vw").value, H = +$("#vh").value;
      if (!(L > 0 && W > 0 && H > 0)) return err("vout", t("Length, width and water height must be greater than zero.","நீளம், அகலம், நீர் உயரம் சுழியை விட அதிகமாக இருக்க வேண்டும்."));
      ok("vout", t("Volume ≈ ","கொள்ளளவு ≈ ") + ((L * W * H) / 1000).toFixed(1) + " L");
    }
    if (kind === "tan") {
      const TAN = +$("#tan").value, pH = +$("#ph").value, T = +$("#tc").value;
      if (!(TAN >= 0 && TAN <= 50)) return err("tout", t("TAN must be 0–50 mg/L as N.","TAN 0–50 mg/L நைட்ரஜனாக இருக்க வேண்டும்."));
      if (!(pH >= 6 && pH <= 10)) return err("tout", t("pH for this teaching tool is limited to 6–10.","இக்கருவிக்கு pH 6–10 மட்டும்."));
      if (!(T >= 5 && T <= 40)) return err("tout", t("Temperature must be 5–40 °C.","வெப்பம் 5–40°செ. இருக்க வேண்டும்."));
      const pKa = 0.09018 + 2729.92 / (273.16 + T);
      const f = 1 / (Math.pow(10, pKa - pH) + 1);
      ok("tout", t("Unionised fraction ","அயனியாகாத விகிதம் ") + f.toFixed(3) +
        t(" · NH₃-N "," · NH₃-N ") + (TAN * f).toFixed(3) + " mg/L. " +
        t("Higher pH and temperature raise the toxic NH₃ share.","pH மற்றும் வெப்பம் உயர்ந்தால் நச்சு NH₃ பங்கு கூடும்."));
    }
    if (kind === "wc") {
      const L = +$("#tl").value, p = +$("#pc").value;
      if (!(L > 0)) return err("wout", t("Volume must be greater than zero.","கொள்ளளவு சுழியை விட அதிகம்."));
      if (!(p > 0 && p <= 100)) return err("wout", t("Percentage must be above 0 and not more than 100.","சதவீதம் 0-க்கு மேல் 100-க்குள்."));
      ok("wout", ((L * p) / 100).toFixed(1) + " L");
    }
    if (kind === "eco") {
      const cap = +$("#cap").value, life = +$("#life").value, opex = +$("#opex").value;
      const prod = +$("#prod").value, price = +$("#price").value, mort = +$("#mort").value;
      if (cap < 0 || opex < 0 || prod < 0 || price < 0) return err("eout", t("Values cannot be negative.","எதிர்மறை மதிப்பு வேண்டாம்."));
      if (!(life > 0)) return err("eout", t("Asset life must be greater than zero.","சொத்து ஆயுள் சுழியை விட அதிகம்."));
      if (!(mort >= 0 && mort <= 100)) return err("eout", t("Mortality must be 0–100 percent.","இறப்பு 0–100 சதவீதம்."));
      const sold = prod * (1 - mort / 100);
      const rev = sold * price;
      const dep = cap / life;
      const profit = rev - opex;
      const roi = cap ? (profit / cap * 100) : 0;
      const bc = (dep + opex) ? (rev / (dep + opex)) : 0;
      ok("eout", t("Saleable units ","விற்கும் அலகு ") + sold.toFixed(0) +
        t(" · revenue ₹"," · வருவாய் ₹") + rev.toFixed(0) +
        t(" · profit (rev−OPEX) ₹"," · லாபம் ₹") + profit.toFixed(0) +
        t(" · depreciation ₹"," · தேய்மானம் ₹") + dep.toFixed(0) +
        t(" · ROI "," · ROI ") + roi.toFixed(1) + "% · B:C " + bc.toFixed(2));
    }
  }

  window.__appBack = function () {
    if (state.fish && !wide()) { state.fish = null; render(); return true; }
    if (state.tab !== "home") { setTab("home"); return true; }
    return false;
  };

  function boot() {
    applyLayout(false);
    try {
      if (!window.__BOOT) throw new Error("Missing embedded data");
      SPECIES = window.__BOOT.species;
      BOOK = window.__BOOT.book;
      QUIZ = window.__BOOT.quiz;
      LABS = window.__BOOT.labs;
    } catch (e) {
      main().innerHTML = "<div class='tile'><h2>" + t("Could not load data","தரவு ஏறவில்லை") + "</h2><p class='muted'>" + e + "</p></div>";
      return;
    }
    document.body.addEventListener("click", onClick);
    document.querySelectorAll("nav.tabs button").forEach((b) => {
      b.addEventListener("click", () => setTab(b.dataset.tab));
    });
    let resizeTimer = null;
    const relayout = () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => applyLayout(true), 80);
    };
    window.addEventListener("resize", relayout);
    window.addEventListener("orientationchange", relayout);
    if (window.visualViewport) window.visualViewport.addEventListener("resize", relayout);
    render();
  }
  boot();
})();
