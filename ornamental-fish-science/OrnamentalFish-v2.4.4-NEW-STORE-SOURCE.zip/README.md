# Ornamental Fish Science — v2.4.4 New Store Identity Release

This source tree is reconstructed from the accepted signed v2.4.3 APK academic payload. The original v2.4.3 private signing key could not be recovered, so this package is intentionally prepared as a **new app identity**, not as an update to the old Indus listing.

## New permanent Android identity
- applicationId / namespace: `com.tnfisheries.ornamentalfish`
- versionName: `2.4.4`
- versionCode: `244`
- minSdk: `24`
- targetSdk: `36`
- permanent release alias: `ornamentalfish`
- permanent release certificate SHA-256: `59F5D6ECBFED41958CA04DA3E23E5CE9ADA98814D5023B053336C39F0D21F51B`

## Authoritative academic baseline
The academic payload is retained from the signed v2.4.3 APK (`com.tnfisheries.ornamental`, APK SHA-256 `F18C9DA32D7AAB62B7F173A3055EB9F0D0BACD54D008D0630CEB38F276E21BC9`):
- 22 species records
- 37 textbook pages
- 21 quiz questions
- 5 practical laboratory activities
- atlas image set and `boot.js` retained

The frozen hashes are in `release-evidence/ACADEMIC_PAYLOAD_SHA256_v2.4.3.txt`.

## Privacy compliance correction
- visible `Privacy Policy / தனியுரிமைக் கொள்கை` entry on Home;
- offline-readable privacy policy bundled in the APK;
- public HTTPS policy for store review;
- external HTTPS policy opens through Android `ACTION_VIEW`;
- no `INTERNET` permission is added to the application.

## Public policy URL
`https://rameshgascngl-create.github.io/Zoology-and-Life-Sciences-Digital-Learning-Resources/ornamental-fish-science/privacy-policy-v2.html`

## GitHub Actions secrets
- `OFISH_KEYSTORE_BASE64`
- `OFISH_KEYSTORE_PASSWORD`
- `OFISH_KEY_ALIAS` = `ornamentalfish`
- `OFISH_KEY_PASSWORD`

Never commit the JKS, passwords, or Base64 keystore text to GitHub. The workflow verifies that the generated APK is signed with the permanent certificate fingerprint listed above.

## Store rule
This APK must be submitted as a **new Indus app listing** because the package ID and signing identity intentionally differ from the unrecoverable v2.4.3 update identity.
