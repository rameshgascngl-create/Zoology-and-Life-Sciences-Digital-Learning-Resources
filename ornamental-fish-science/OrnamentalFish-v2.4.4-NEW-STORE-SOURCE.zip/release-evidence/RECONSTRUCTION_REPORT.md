# Ornamental Fish Science v2.4.4 — Reconstruction / Privacy Fix Report

## Input release
- Package: `com.tnfisheries.ornamental`
- Input version: `2.4.3 / 243`
- Input APK SHA-256: `f18c9da32d7aab62b7f173a3055eb9f0d0bacd54d008d0630ceb38f276e21bc9`
- Input certificate SHA-256: `a0fcf7b98242e4652793ef686d94ee30d3309eef56eb0697993d32159ba74b7f`

## Supplied release-package audit
The user-supplied release ZIP contains the APK, licence register, third-party notices, audit report and checksums. It contains neither the Android source tree nor the private signing keystore.

## v2.4.4 correction
- Android identity preserved.
- Version advanced to `2.4.4 / 244` to avoid Indus `Version already present`.
- Academic payload frozen from the signed v2.4.3 APK.
- Visible in-app privacy entry added.
- Local offline policy added at `file:///android_asset/privacy-policy.html`.
- Public policy link added to the local policy page.
- Native WebView intercepts `http`/`https` and launches `ACTION_VIEW`; no INTERNET permission required.
- Existing responsive WebView settings retained: JavaScript and DOM storage enabled, wide viewport enabled, overview mode disabled.

## Release blocker
STORE-READY APK generation is blocked until the original private signing key is supplied or restored through GitHub Actions secrets. A replacement key would cause signature mismatch and is prohibited for this update.
