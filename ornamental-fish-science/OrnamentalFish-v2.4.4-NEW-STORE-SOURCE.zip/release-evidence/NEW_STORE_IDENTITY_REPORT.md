# Ornamental Fish Science v2.4.4 — New Store Identity Report

## Why a new identity is required
The accepted v2.4.3 APK uses package `com.tnfisheries.ornamental` and certificate SHA-256 `A0FCF7B98242E4652793EF686D94EE30D3309EEF56EB0697993D32159BA74B7F`. The corresponding private signing key was not present in the release package, prior source archives, local keystore scans, or PowerShell history. A private key cannot be recovered from the public certificate embedded in an APK.

Therefore this release is not an update to the old listing.

## New identity
- package: `com.tnfisheries.ornamentalfish`
- versionName: `2.4.4`
- versionCode: `244`
- minSdk: `24`
- targetSdk: `36`
- signing alias: `ornamentalfish`
- certificate SHA-256: `59F5D6ECBFED41958CA04DA3E23E5CE9ADA98814D5023B053336C39F0D21F51B`

## Payload preservation
The academic payload remains frozen to the accepted v2.4.3 baseline. Only the Android identity, signing identity, release metadata, and privacy-compliance layer are intentionally changed.

## Submission classification
NEW INDUS APP LISTING REQUIRED.
Do not upload this APK as a replacement binary for the old `com.tnfisheries.ornamental` listing.
