# Next phase: build, then controlled beta testing

1. Publish this project to a dedicated source branch, preserving the existing repository and historical ZIPs. The ZIP contents belong at that branch's repository root. This handoff has not pushed, dispatched a workflow, or published a release.
2. Run the included GitHub Actions workflow. All source checks, Android lint, Android unit-test task and build tasks must succeed. Download the artifact named from the actual Gradle version. Keep its matching source ZIP with the APK.
3. Install the debug APK only on a test handset or test profile. A debug build is not a production-signed release. If an existing installation uses another signing key, do not silently uninstall it; decide how to protect any local data first.
4. Test at minimum an older supported Android/WebView combination, a current Android 15/16 device, a narrow phone, and a larger screen. Test portrait and landscape, large system font, screen-reader labels, three-button navigation and gesture navigation.
5. Use the checklist below. Record PASS/FAIL, device/WebView versions, screenshot and reproduction steps for each failure.
6. Ask a bilingual Environmental Studies teacher to check the 25 Tamil explanation additions and terminology. Check regulatory/legal figures against the latest authoritative sources; this source audit is not legal or scientific certification.
7. Only after these checks pass, prepare a signed release APK/AAB with the existing release identity, review privacy/store declarations and distribute to a small beta group. Keep the signing key private and backed up.

## Handset acceptance checklist

- Fresh launch shows the cover; Start reading opens About.
- Contents opens lessons, unit introductions, reviews, all nine quizzes and appendices.
- Previous/Next works repeatedly and rapidly; final References page is reachable.
- Long English, Tamil and EN+TA lessons scroll to their final line without clipping or jumping on resize.
- System bars/cutouts do not cover controls or the final lines, including Android 16.
- Figures mode preserves the selected language. English and Tamil figures enlarge/reduce and horizontal scrolling works.
- Search works in both languages; Clear and a newer query cannot be overwritten by a late result.
- MCQ selection, correct/incorrect/unanswered feedback and score work; keyboard arrows on inputs do not change the page.
- Language/page restore after closing, reopening and rotation. MCQ selections are not promised to persist.
- Privacy footer is reachable in portrait/landscape; Back returns to the book, including modern gesture Back.
- A failed unit load retries the failed destination. Use a deliberately broken test-only build if needed; do not alter the shipped bundle.
- All functions work in airplane mode; no account or unnecessary permission request appears.

If a build or device check fails, provide the workflow log or device reproduction before the next release. Do not label this candidate “final audited APK” based on source checks alone.
