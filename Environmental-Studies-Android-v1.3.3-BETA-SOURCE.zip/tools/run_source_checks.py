"""Run reproducible local checks and write a clearly scoped test record."""
from pathlib import Path
import datetime,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
commands=[[sys.executable,'tools/sync_version.py','--check'],[sys.executable,'tools/verify_content_integrity.py'],
          [sys.executable,'tools/test_verifier.py'],['node','tools/test_reader.cjs']]
record=['Environmental Studies source check record',datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'Scope: source structure, integrity and Node VM behavior only. No Android compilation, lint, emulator or handset test is implied.','']
failed=False
for command in commands:
    result=subprocess.run(command,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    label=' '.join(['python' if i==0 and arg==sys.executable else arg for i,arg in enumerate(command)])
    record.extend(['COMMAND: '+label,'EXIT: '+str(result.returncode),result.stdout])
    print(label+': '+('PASS' if result.returncode==0 else 'FAIL'))
    failed=failed or result.returncode!=0
(ROOT/'verification/source-test-results.txt').write_text('\n'.join(record),encoding='utf-8')
sys.exit(1 if failed else 0)
