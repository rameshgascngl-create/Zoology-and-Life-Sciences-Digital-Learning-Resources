package edu.gascnagercoil.environmentalsciences;

import android.app.Activity;
import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.net.Uri;
import android.os.Build;
import android.window.OnBackInvokedDispatcher;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.json.JSONObject;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private WebView webView;
    private ScrollView scrollView;
    private WebViewAssetLoader assetLoader;
    private Button previousButton;
    private Button nextButton;
    private Button visualButton;
    private int currentBookIndex = 0;
    private String pendingAction = null;
    private int pageCount;
    private boolean scrollToTop = true;

    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private static final String PRIVACY = "https://appassets.androidplatform.net/assets/privacy.html";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) currentBookIndex = savedInstanceState.getInt("bookIndex", 0);
        try (InputStream input = getAssets().open("book-catalog.json")) {
            java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int count;
            while ((count = input.read(buffer)) != -1) bytes.write(buffer, 0, count);
            pageCount = new JSONObject(bytes.toString("UTF-8")).getJSONArray("pages").length();
        } catch (Exception error) {
            Toast.makeText(this, "The bundled catalog is unavailable.", Toast.LENGTH_LONG).show();
            finish(); return;
        }
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        getWindow().setStatusBarColor(Color.rgb(31,101,82));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(31,101,82));
        // Target 36 cannot opt out of edge-to-edge. Keep every control outside bars/cutouts.
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets safe = insets.getInsets(
                    android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout()
                    | android.view.WindowInsets.Type.ime());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return insets;
            });
        }

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(5), dp(5), dp(5), dp(5));
        controls.setBackgroundColor(Color.rgb(248,251,249));
        root.addView(controls, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row1 = makeRow();
        LinearLayout row2 = makeRow();
        controls.addView(row1, new LinearLayout.LayoutParams(-1, dp(54)));
        controls.addView(row2, new LinearLayout.LayoutParams(-1, dp(54)));

        Button contents = makeButton("☰ Contents");
        previousButton = makeButton("←");
        nextButton = makeButton("→");
        previousButton.setContentDescription("Previous page / முந்தைய பக்கம்");
        nextButton.setContentDescription("Next page / அடுத்த பக்கம்");
        visualButton = makeButton("▣ Figures");
        addWeighted(row1, contents, 1.55f);
        addWeighted(row1, previousButton, .55f);
        addWeighted(row1, nextButton, .55f);
        addWeighted(row1, visualButton, 1.15f);

        Button privacy = makeButton("Privacy");
        Button english = makeButton("English");
        Button tamil = makeButton("தமிழ்");
        Button both = makeButton("EN+TA");
        addWeighted(row2, privacy, 1f);
        addWeighted(row2, english, 1f);
        addWeighted(row2, tamil, 1f);
        addWeighted(row2,both,1f);

        /*
         * v1.2.9: scrolling is deliberately owned by a native ScrollView.
         * The WebView is expanded to the rendered document height reported
         * through AndroidHost.pageRendered(). This avoids OEM WebView touch/
         * scroll failures seen on the test handset.
         */
        scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(Color.rgb(255,253,248));
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(true);
        scrollView.setHorizontalScrollBarEnabled(false);
        scrollView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255,253,248));
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setNestedScrollingEnabled(false);
        webView.setFocusable(true);
        webView.setClickable(true);

        // ScrollView handles vertical interception; do not cancel horizontal figure gestures.

        ScrollView.LayoutParams webParams =
            new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, dp(640));
        scrollView.addView(webView, webParams);
        root.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30) root.requestApplyInsets();

        assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);
        WebView.setWebContentsDebuggingEnabled(false);

        webView.addJavascriptInterface(new ReaderHost(), "AndroidHost");

        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {
                if (!isLocalAsset(request.getUrl())) return blockedResponse();
                WebResourceResponse response = assetLoader.shouldInterceptRequest(request.getUrl());
                return response != null ? response : blockedResponse();
            }

            @Override public boolean shouldOverrideUrlLoading(
                    WebView view, WebResourceRequest request) {
                return !isLocalAsset(request.getUrl());
            }

            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (HOME.equals(url)) {
                    String action = pendingAction == null ? "" : pendingAction;
                    pendingAction = null;
                    runReaderAction(action);
                } else {
                    // Privacy is a normal local page; measure it as well.
                    js("if(window.reportHostHeight)window.reportHostHeight(true);");
                }
            }
        });

        contents.setOnClickListener(v -> readerAction("await navigateToKey('front-2');"));
        previousButton.setOnClickListener(v -> readerAction("await navigateRelative(-1);"));
        nextButton.setOnClickListener(v -> readerAction("await navigateRelative(1);"));

        visualButton.setOnClickListener(v -> {
            if (!HOME.equals(webView.getUrl())) {
                Toast.makeText(this, "Visual mode is available in the textbook.", Toast.LENGTH_SHORT).show();
                return;
            }
            webView.evaluateJavascript(
                "(function(){try{return window.nativeToggleVisual?window.nativeToggleVisual():false;}catch(e){return false;}})();",
                value -> {
                    if ("\"none\"".equals(value)) Toast.makeText(this, "No figures on this page / இந்தப் பக்கத்தில் படங்கள் இல்லை", Toast.LENGTH_SHORT).show();
                    boolean on = "\"on\"".equals(value);
                    visualButton.setText(on ? "▣ Full page" : "▣ Figures");
                    visualButton.setActivated(on);
                    webView.postDelayed(this::requestHeightSync, 80);
                });
        });

        privacy.setOnClickListener(v -> { scrollToTop = true; webView.loadUrl(PRIVACY); });

        english.setOnClickListener(v -> changeLanguage("en"));
        tamil.setOnClickListener(v -> changeLanguage("ta"));
        both.setOnClickListener(v -> changeLanguage("both"));

        if (Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
            OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBackNavigation);

        if (savedInstanceState == null) {
            webView.loadUrl(HOME);
        } else {
            if (webView.restoreState(savedInstanceState) == null) webView.loadUrl(HOME);
        }
    }

    private void readerAction(String action) {
        scrollToTop = true;
        visualButton.setText("▣ Figures");
        visualButton.setActivated(false);
        if (!HOME.equals(webView.getUrl())) {
            pendingAction = action;
            webView.loadUrl(HOME);
            return;
        }
        runReaderAction(action);
    }

    private void runReaderAction(String action) {
        js("(async()=>{await window.readerReady;" + action +
           "if(window.reportHostHeight)window.reportHostHeight(true);})().catch(console.error);");
    }

    private void changeLanguage(String language) {
        if (!"en".equals(language) && !"ta".equals(language) && !"both".equals(language)) return;
        readerAction("document.body.classList.remove('visual-focus');setLang('" + language + "');");
    }

    private void requestHeightSync() {
        if (webView != null && HOME.equals(webView.getUrl())) {
            js("if(window.reportHostHeight)window.reportHostHeight();");
        }
    }

    private final class ReaderHost {
        // The only exposed method. Never add data access, intents, or network operations here.
        // Only bundled assets may call it; all inputs are validated again on the UI thread.
        @JavascriptInterface
        public void pageRendered(int pageIndex, double cssHeight) {
            if (!Double.isFinite(cssHeight) || cssHeight <= 0 || cssHeight > 200000) return;
            if (pageIndex < -1 || pageIndex >= pageCount) return;
            runOnUiThread(() -> {
                if (webView == null) return;
                boolean privacy = PRIVACY.equals(webView.getUrl());
                if ((pageIndex == -1) != privacy || (!privacy && !HOME.equals(webView.getUrl()))) return;
                boolean changed = !privacy && pageIndex != currentBookIndex;
                if (!privacy) currentBookIndex = pageIndex;
                previousButton.setEnabled(privacy || currentBookIndex > 0);
                nextButton.setEnabled(privacy || currentBookIndex < pageCount - 1);
                if (changed) { visualButton.setText("▣ Figures"); visualButton.setActivated(false); }
                resizeWebView(cssHeight);
                if (changed || scrollToTop) scrollView.post(() -> { if (webView != null) scrollView.scrollTo(0, 0); });
                scrollToTop = false;
            });
        }
    }

    private void resizeWebView(double cssHeight) {
        if (webView == null) return;
        float density = getResources().getDisplayMetrics().density;
        int requested = (int)Math.ceil(Math.max(1d, cssHeight) * density);
        int minimum = Math.max(dp(520), scrollView != null ? scrollView.getHeight() : 0);
        int height = Math.max(minimum, requested + dp(12));
        android.view.ViewGroup.LayoutParams lp = webView.getLayoutParams();
        if (lp.height != height) {
            lp.height = height;
            webView.setLayoutParams(lp);
            webView.requestLayout();
        }
    }

    private LinearLayout makeRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private Button makeButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(4), 0, dp(4), 0);
        return button;
    }

    private void addWeighted(LinearLayout row, View view, float weight) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, weight);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        row.addView(view, lp);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void js(String code) {
        if (webView == null) return;
        webView.evaluateJavascript(
            "(function(){try{" + code + "}catch(e){console.error(e);}})();",
            null);
    }

    private static boolean isLocalAsset(Uri uri) {
        return "https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost())
            && uri.getPort() == -1 && uri.getUserInfo() == null && uri.getPath() != null
            && uri.getPath().startsWith("/assets/") && !uri.getPath().contains("..");
    }

    private static WebResourceResponse blockedResponse() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden", null,
            new ByteArrayInputStream(new byte[0]));
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        outState.putInt("bookIndex", currentBookIndex);
        super.onSaveInstanceState(outState);
    }

    private void handleBackNavigation() {
        if (webView == null) { finish(); return; }
        if (!HOME.equals(webView.getUrl())) {
            scrollToTop = true;
            webView.loadUrl(HOME);
            return;
        }
        webView.evaluateJavascript(
            "(function(){try{return !!(window.handleAppBack&&window.handleAppBack());}catch(e){return false;}})();",
            value -> {
                if (!"true".equals(value)) {
                    finish();
                }
            });
    }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() {
        handleBackNavigation();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidHost");
            webView.stopLoading();
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
