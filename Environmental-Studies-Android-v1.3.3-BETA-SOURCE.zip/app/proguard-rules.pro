# Keep the single annotated sizing callback callable in minified release builds.
# Any additional bridge method requires a security review and verifier changes.
-keepclassmembers class edu.gascnagercoil.environmentalsciences.MainActivity$ReaderHost {
    @android.webkit.JavascriptInterface public void pageRendered(int, double);
}
