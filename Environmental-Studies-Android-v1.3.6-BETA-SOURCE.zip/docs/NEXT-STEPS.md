# Next phase: validate v1.3.6 and capture Play assets

1. Confirm the complete source, rendered-layout, JVM, lint and Android build gates pass. Retain the APK, exact source ZIP, DEX report and provenance from the same CI run.
2. Install the beta on a dedicated test device/profile. Do not disable Play Protect. A debug-key signature mismatch may require a separately planned migration; uninstalling can erase local preferences.
3. Test one mdpi/hdpi-class screen and one xxhdpi/xxxhdpi screen. Confirm that cover statistics are separate, Contents titles use separate English/Tamil lines, and no large blank region can be scrolled.
4. Turn pages rapidly several times, rotate the device, return from Privacy and change system font/display size. Confirm an older height callback never stretches the current page.
5. On lesson 1.2 and other English/Tamil figures, test tap-to-expand, pinch, −, + and Reset. At 100% the complete figure must fit; at higher zoom only the diagram may pan sideways, while the heading, caption and page remain fixed.
6. Test portrait/landscape, TalkBack, gesture navigation, three-button navigation, airplane mode, app restart and reading-position restore. Include an older supported Android/WebView and Android 15/16 if available.
7. For every issue, record the page key/title, screenshot or short recording, phone model, density/resolution, Android/WebView version, font/display scale and exact reproduction steps.
8. After device acceptance, recapture clean 1080 × 1920 portrait screenshots from v1.3.6; do not reuse the defective v1.3.5 cover, Contents or enlarged-figure images. Then create and back up a stable upload/release key, configure a protected signed build, produce the Play AAB, review store declarations and arrange academic/Tamil terminology review.
