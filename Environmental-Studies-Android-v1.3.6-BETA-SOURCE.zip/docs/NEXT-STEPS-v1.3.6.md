# Next phase: validate v1.3.6 and capture Play assets

1. Use only the APK and matching source produced by the same successful v1.3.6 CI run. Record their SHA-256 hashes and retain the DEX/provenance reports.
2. Install on a dedicated test device/profile. Keep Play Protect enabled. If a signing conflict appears, do not uninstall the existing app until any preference-loss consequence has been considered.
3. Test the cover at normal and large system font sizes. Confirm the four facts are distinct and no English/Tamil words join.
4. Open Contents at 320–412 CSS-pixel phone widths. Confirm every English lesson title is followed by its Tamil title on a separate line.
5. Open lesson 1.2 and enlarge the Earth-systems figure. At 100% the complete figure must fit. At 125–300%, only the diagram should pan sideways; its heading, caption, tags and the page must not slide or clip. Reset must restore the fitted view.
6. Complete the wider beta checklist: long-page scrolling, bottom navigation, Figures/Full page, quizzes, Android Back, Privacy footer, rotation, large text, airplane mode, restart and reading-position restore. Test at least one mdpi/hdpi-class and one xxhdpi/xxxhdpi device.
7. Record every failure with page key/title, phone model, resolution/density, Android and WebView versions, font/display scale, exact steps and a screenshot or short recording.
8. After handset acceptance, recapture at least two clean portrait screenshots from v1.3.6. Use 1080 × 1920 PNG or JPEG, avoid debug overlays and do not reuse the defective v1.3.5 cover, Contents or enlarged-figure images.
9. Before public release, create and back up a stable production upload key, configure signed AAB generation, complete Play Console privacy/data-safety declarations, and obtain academic/Tamil terminology review.
