/* Security contract: one read-only sizing callback; no filesystem/network capability. */
(function(){
  'use strict';
  const host=window.AndroidHost;
  if(host)document.body.classList.add('native-host');
  let frame=0,lastHeight=-1,lastIndex=-2,pendingForce=false;
  const figureSelector='.naturalplate svg,.explainer svg,.visual svg,.ta-figure-card svg';
  window.reportHostHeight=function(force=false){
    pendingForce=pendingForce||force===true;
    cancelAnimationFrame(frame);
    frame=requestAnimationFrame(()=>{
      const forced=pendingForce;pendingForce=false;
      if(!host||typeof host.pageRendered!=='function')return;
      const page=document.getElementById('bookPage');
      const footer=document.getElementById('privacyFooter');
      const toc=document.getElementById('bookToc');
      const target=footer||page;if(!target)return;
      const bottom=target.getBoundingClientRect().bottom+window.scrollY;
      const tocBottom=toc?.classList.contains('open')?toc.getBoundingClientRect().bottom+window.scrollY:0;
      const height=Math.ceil(Math.max(bottom,tocBottom)+(parseFloat(getComputedStyle(document.body).paddingBottom)||0)+2);
      const index=footer?-1:(typeof bookIndex==='number'?bookIndex:0);
      const viewportWidth=document.documentElement.clientWidth;
      const generation=footer?0:(typeof readerRenderGeneration==='number'?readerRenderGeneration:0);
      if(Number.isFinite(height)&&height>0&&(forced||height!==lastHeight||index!==lastIndex)){
        lastHeight=height;lastIndex=index;host.pageRendered(index,height,viewportWidth,generation);
      }
    });
  };
  window.prepareVisualFocus=function(){
    const page=document.getElementById('bookPage');if(!page)return;
    page.querySelectorAll('.figure-branch').forEach(x=>x.classList.remove('figure-branch'));
    page.querySelectorAll(figureSelector).forEach(svg=>{
      svg.setAttribute('role','button');svg.setAttribute('tabindex','0');
      svg.setAttribute('aria-expanded',svg.parentElement.classList.contains('figure-expanded')?'true':'false');
      svg.setAttribute('aria-label','Enlarge or reduce figure / படத்தைப் பெரிதாக்கு அல்லது சிறிதாக்கு');
      let node=svg.parentElement;
      while(node&&node!==page){node.classList.add('figure-branch');node=node.parentElement;}
    });
    const button=document.getElementById('visualOnlyBtn');
    if(button){button.textContent=document.body.classList.contains('visual-focus')?'Full page / முழுப் பக்கம்':'Figures / படங்கள்';button.setAttribute('aria-pressed',document.body.classList.contains('visual-focus')?'true':'false');}
  };
  window.nativeToggleVisual=function(){
    const page=document.getElementById('bookPage');
    if(!page||![...page.querySelectorAll(figureSelector)].some(x=>x.getClientRects().length))return 'none';
    document.body.classList.toggle('visual-focus');window.prepareVisualFocus();window.reportHostHeight();
    return document.body.classList.contains('visual-focus')?'on':'off';
  };
  const gestureState=new WeakMap();
  function scaleFigure(container,scale){
    scale=Math.max(1,Math.min(3,Number(scale)||1));
    container.style.setProperty('--figure-scale',scale.toFixed(3));
    container.dataset.figureScale=String(scale);
    const output=container.querySelector('.figure-zoom-controls output');
    if(output)output.value=Math.round(scale*100)+'%';
    window.reportHostHeight();
    return scale;
  }
  function addZoomControls(container){
    if(container.querySelector(':scope > .figure-zoom-controls'))return;
    const controls=document.createElement('div');controls.className='figure-zoom-controls';
    controls.setAttribute('role','group');controls.setAttribute('aria-label','Figure zoom / படப் பெரிதாக்கம்');
    controls.innerHTML='<button type="button" data-figure-scale="out" aria-label="Zoom out / சிறிதாக்கு">−</button>'+
      '<output aria-live="polite">100%</output>'+
      '<button type="button" data-figure-scale="in" aria-label="Zoom in / பெரிதாக்கு">+</button>'+
      '<button type="button" data-figure-scale="reset">Reset / மீட்டமை</button>';
    container.prepend(controls);scaleFigure(container,1);
  }
  function removeZoomControls(container){container.querySelector(':scope > .figure-zoom-controls')?.remove();container.style.removeProperty('--figure-scale');delete container.dataset.figureScale;}
  function toggleFigure(svg){
    if(!svg)return;
    const container=svg.parentElement,expanded=container.classList.toggle('figure-expanded');
    if(expanded)addZoomControls(container);else removeZoomControls(container);
    svg.setAttribute('aria-expanded',expanded?'true':'false');window.reportHostHeight();
  }
  document.addEventListener('click',event=>{
    if(event.target.closest?.('#visualOnlyBtn')){
      if(window.nativeToggleVisual()==='none')window.alert('No figures on this page / இந்தப் பக்கத்தில் படங்கள் இல்லை');
      return;
    }
    const zoom=event.target.closest?.('[data-figure-scale]');
    if(zoom){
      const container=zoom.closest('.figure-expanded');if(!container)return;
      const current=Number(container.dataset.figureScale)||1,action=zoom.dataset.figureScale;
      scaleFigure(container,action==='in'?current+.25:action==='out'?current-.25:1);return;
    }
    const svg=event.target.closest?.(figureSelector);
    if(svg&&Date.now()<(gestureState.get(svg)?.ignoreClickUntil||0)){event.preventDefault();return;}
    toggleFigure(svg);
  });
  document.addEventListener('touchstart',event=>{
    const svg=event.target.closest?.(figureSelector);if(!svg||!svg.parentElement.classList.contains('figure-expanded')||event.touches.length!==2)return;
    const dx=event.touches[0].clientX-event.touches[1].clientX,dy=event.touches[0].clientY-event.touches[1].clientY;
    gestureState.set(svg,{distance:Math.hypot(dx,dy),scale:Number(svg.parentElement.dataset.figureScale)||1,pinching:true,ignoreClickUntil:0});
    event.preventDefault();
  },{passive:false});
  document.addEventListener('touchmove',event=>{
    const svg=event.target.closest?.(figureSelector),state=svg&&gestureState.get(svg);
    if(!svg||!state?.pinching||event.touches.length!==2)return;
    const dx=event.touches[0].clientX-event.touches[1].clientX,dy=event.touches[0].clientY-event.touches[1].clientY;
    scaleFigure(svg.parentElement,state.scale*Math.hypot(dx,dy)/Math.max(1,state.distance));event.preventDefault();
  },{passive:false});
  document.addEventListener('touchend',event=>{
    const svg=event.target.closest?.(figureSelector),state=svg&&gestureState.get(svg);if(!state?.pinching)return;
    state.pinching=false;state.ignoreClickUntil=Date.now()+400;gestureState.set(svg,state);window.reportHostHeight(true);
  });
  document.addEventListener('keydown',event=>{
    if((event.key==='Enter'||event.key===' ')&&event.target.matches?.(figureSelector)){event.preventDefault();toggleFigure(event.target);}
    if(event.key==='Escape')window.closeExpandedFigure();
  });
  window.closeExpandedFigure=function(){
    const expanded=document.querySelector('.figure-expanded');if(!expanded)return false;
    expanded.classList.remove('figure-expanded');removeZoomControls(expanded);expanded.querySelector('svg')?.setAttribute('aria-expanded','false');window.reportHostHeight();return true;
  };
  window.addEventListener('load',()=>{window.prepareVisualFocus();window.reportHostHeight();});
  window.addEventListener('resize',()=>window.reportHostHeight());
  if(document.fonts)document.fonts.ready.then(()=>window.reportHostHeight());
  if(typeof ResizeObserver==='function'){
    const observer=new ResizeObserver(()=>window.reportHostHeight());
    for(const id of ['bookPage','privacyFooter','bookToc']){const node=document.getElementById(id);if(node)observer.observe(node);}
  }
})();
