package edu.gascnagercoil.environmentalsciences;

/** Pure sizing math, kept Android-free so density and page-scale cases can be unit tested. */
final class WebHeightMath {
    private WebHeightMath() {}

    // CSS pixels are converted using the live physical-view-width/CSS-viewport-width ratio.
    // This works at mdpi/xxhdpi and when WebView page scale differs from display density.
    static int calculate(double cssHeight, double cssViewportWidth, int viewWidth) {
        if (!Double.isFinite(cssHeight) || !Double.isFinite(cssViewportWidth)
                || cssHeight <= 0 || cssViewportWidth <= 0 || viewWidth <= 0) return -1;
        double pixelsPerCssPixel = viewWidth / cssViewportWidth;
        if (!Double.isFinite(pixelsPerCssPixel) || pixelsPerCssPixel < 0.25d
                || pixelsPerCssPixel > 10d) return -1;
        double requested = Math.ceil(cssHeight * pixelsPerCssPixel);
        return requested >= 1d && requested <= Integer.MAX_VALUE ? (int) requested : -1;
    }
}
