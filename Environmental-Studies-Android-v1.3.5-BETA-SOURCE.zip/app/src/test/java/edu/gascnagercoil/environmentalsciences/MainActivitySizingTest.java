package edu.gascnagercoil.environmentalsciences;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MainActivitySizingTest {
    @Test public void convertsCssHeightUsingMeasuredViewportRatio() {
        assertEquals(617, WebHeightMath.calculate(617, 360, 360));
        assertEquals(1234, WebHeightMath.calculate(617, 360, 720));
        assertEquals(1851, WebHeightMath.calculate(617, 360, 1080));
        assertEquals(1887, WebHeightMath.calculate(629, 412, 1236));
    }

    @Test public void rejectsInvalidOrImplausibleMeasurements() {
        assertEquals(-1, WebHeightMath.calculate(Double.NaN, 360, 1080));
        assertEquals(-1, WebHeightMath.calculate(617, 0, 1080));
        assertEquals(-1, WebHeightMath.calculate(617, 360, 0));
        assertEquals(-1, WebHeightMath.calculate(617, 360, 10000));
    }
}
