"""Single-source README and release metadata: python tools/sync_version.py [--check]."""
from pathlib import Path
import argparse,json,re,sys
ROOT=Path(__file__).resolve().parents[1]
START='<!-- release-metadata:start -->';END='<!-- release-metadata:end -->'
def rendered_block(root=ROOT):
    gradle=(root/'app/build.gradle').read_text()
    name=re.search(r"versionName\s+'([^']+)'",gradle).group(1)
    code=re.search(r'versionCode\s+(\d+)',gradle).group(1)
    pages=len(json.loads((root/'app/src/main/assets/book-catalog.json').read_text())['pages'])
    return f'{START}\n# Environmental Studies Android — v{name} beta\n\nversionName: `{name}` · versionCode: `{code}` · reader pages: {pages}\n{END}'
def release_metadata(root=ROOT):
    gradle=(root/'app/build.gradle').read_text()
    return {
        'app_name':'Environmental Studies',
        'version_name':re.search(r"versionName\s+'([^']+)'",gradle).group(1),
        'version_code':int(re.search(r'versionCode\s+(\d+)',gradle).group(1)),
        'package':re.search(r"applicationId\s+'([^']+)'",gradle).group(1),
        'reader_pages':len(json.loads((root/'app/src/main/assets/book-catalog.json').read_text())['pages']),
        'content_baseline':'Nine unit files unchanged from v1.3.4',
        'content_revision_manifest':'verification/release-integrity.json',
        'scope':'Source metadata, not build certification. Use current CI build-provenance.json for APK evidence.'
    }
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true');args=parser.parse_args()
    path=ROOT/'README.md';text=path.read_text();block=rendered_block()
    metadata_path=ROOT/'verification/app-build-metadata.json';metadata=release_metadata()
    if args.check:
        if block not in text:sys.exit('README version drift: run python tools/sync_version.py')
        if json.loads(metadata_path.read_text())!=metadata:sys.exit('Release metadata drift: run python tools/sync_version.py')
        print('VERSION PASS');sys.exit(0)
    if START not in text or END not in text:sys.exit('README metadata markers missing')
    path.write_text(re.sub(re.escape(START)+r'.*?'+re.escape(END),lambda _:block,text,flags=re.S),encoding='utf-8')
    metadata_path.write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
