#!/usr/bin/env python3
"""Report the real DEX payloads produced by the release build."""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = {
    "debug_apk": ROOT / "app/build/outputs/apk/debug/app-debug.apk",
    "release_unsigned_apk": ROOT / "app/build/outputs/apk/release/app-release-unsigned.apk",
    "release_aab": ROOT / "app/build/outputs/bundle/release/app-release.aab",
}


def analyse(path: Path) -> dict:
    with ZipFile(path) as archive:
        dex_names = sorted(
            (name for name in archive.namelist() if re.search(r"(?:^|/)classes\d*\.dex$", name)),
            key=lambda name: (len(name), name),
        )
        entries = []
        kotlin_marker = False
        for name in dex_names:
            payload = archive.read(name)
            kotlin_marker = kotlin_marker or b"Lkotlin/" in payload or b"kotlin/" in payload
            entries.append({
                "name": name,
                "uncompressed_bytes": len(payload),
                "sha256": hashlib.sha256(payload).hexdigest(),
            })
    return {
        "file": path.name,
        "file_bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "dex_count": len(entries),
        "dex_uncompressed_bytes": sum(item["uncompressed_bytes"] for item in entries),
        "contains_kotlin_marker": kotlin_marker,
        "dex_entries": entries,
    }


def main() -> int:
    missing = [str(path) for path in OUTPUTS.values() if not path.is_file()]
    if missing:
        print("DEX REPORT FAIL: missing build outputs: " + ", ".join(missing), file=sys.stderr)
        return 1
    report = {
        "schema": 1,
        "scope": "Actual Gradle build outputs; release APK is unsigned unless a signing configuration is supplied.",
        "artifacts": {label: analyse(path) for label, path in OUTPUTS.items()},
    }
    destination = ROOT / "verification/release-dex-report.json"
    destination.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    for label, result in report["artifacts"].items():
        print(f"{label}: {result['dex_count']} DEX, {result['dex_uncompressed_bytes']} uncompressed bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
