"""Negative tests prove that the verifier rejects structural faults, not just hash drift."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json,shutil,unittest
from bs4 import BeautifulSoup
from verify_content_integrity import ROOT,verify

class VerifierTests(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory(prefix='es-verifier-')
        self.root=Path(self.temp.name)/'project'
        shutil.copytree(ROOT,self.root,ignore=shutil.ignore_patterns('__pycache__','.git','.gradle','build','.verify-venv'))
        self.assets=self.root/'app/src/main/assets'
    def tearDown(self):self.temp.cleanup()
    def test_valid_release(self):self.assertEqual(verify(self.root),[])
    def test_bogus_catalog_destinations_fail_without_hash_check(self):
        path=self.assets/'book-catalog.json';data=json.loads(path.read_text())
        for page in data['pages']:
            if page['type']=='lesson':page['unitFile']='units/nonexistent.html'
        path.write_text(json.dumps(data));errors=verify(self.root,False)
        self.assertTrue(any('catalog source resolution' in x for x in errors))
        self.assertTrue(any('catalog unit file' in x for x in errors))
    def test_tamil_removal_fails_without_hash_check(self):
        path=self.assets/'units/unit-01.html';doc=BeautifulSoup(path.read_text(),'html.parser')
        doc.select_one('.lesson-language.ta').decompose();path.write_text(str(doc))
        self.assertIn('English then Tamil u1l1',verify(self.root,False))
    def test_duplicate_svg_fails_without_hash_check(self):
        path=self.assets/'units/unit-01.html';doc=BeautifulSoup(path.read_text(),'html.parser')
        nodes=doc.select('svg [id]');nodes[1]['id']=nodes[0]['id'];path.write_text(str(doc))
        self.assertIn('unique DOM/SVG ids unit-01.html',verify(self.root,False))
    def test_invalid_answer_fails_without_hash_check(self):
        path=self.assets/'units/unit-01.html';doc=BeautifulSoup(path.read_text(),'html.parser')
        doc.select_one('.mcq')['data-answer']='9';path.write_text(str(doc))
        self.assertTrue(any('MCQ answer' in x for x in verify(self.root,False)))
    def test_hash_tamper_fails(self):
        path=self.assets/'reader.css';path.write_text(path.read_text()+'\n/* unreviewed edit */\n')
        self.assertIn('hash app/src/main/assets/reader.css',verify(self.root))
    def test_readme_drift_fails(self):
        path=self.root/'README.md';path.write_text(path.read_text().replace('versionName: `1.3.5`','versionName: `1.2.4`'))
        self.assertIn('README synchronized version block',verify(self.root,False))
    def test_release_metadata_drift_fails(self):
        path=self.root/'verification/app-build-metadata.json';data=json.loads(path.read_text())
        data['version_name']='1.2.4';path.write_text(json.dumps(data))
        self.assertIn('release metadata synchronized',verify(self.root,False))

if __name__=='__main__':unittest.main(verbosity=2)
