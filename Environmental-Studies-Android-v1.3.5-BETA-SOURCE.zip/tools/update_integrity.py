"""Explicit maintainer operation after review; never invoked automatically by CI."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[1]
gradle=(ROOT/'app/build.gradle').read_text()
files=[]
for name in ['app/src','tools','.github/workflows']:
    files.extend(p for p in (ROOT/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
files.extend(ROOT/name for name in ['README.md','app/build.gradle','build.gradle','settings.gradle','gradle.properties','app/proguard-rules.pro','verification/app-build-metadata.json'])
data={'version':re.search(r"versionName\s+'([^']+)'",gradle).group(1),'versionCode':int(re.search(r'versionCode\s+(\d+)',gradle).group(1)),
      'sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}}
(ROOT/'verification/release-integrity.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(f'Updated reviewed integrity snapshot: {len(files)} files')
