#!/usr/bin/env python3
"""Unit tests for DEX artifact reporting without requiring an Android build."""
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile

from report_dex import analyse


class DexReportTest(unittest.TestCase):
    def test_counts_and_hashes_all_dex_entries(self):
        with tempfile.TemporaryDirectory() as directory:
            artifact = Path(directory) / "sample.aab"
            with ZipFile(artifact, "w") as archive:
                archive.writestr("base/dex/classes.dex", b"dex\nLkotlin/Unit;")
                archive.writestr("base/dex/classes2.dex", b"second")
                archive.writestr("base/assets/index.html", b"ignored")
            result = analyse(artifact)
            self.assertEqual(result["dex_count"], 2)
            self.assertEqual(result["dex_uncompressed_bytes"], 23)
            self.assertTrue(result["contains_kotlin_marker"])
            self.assertEqual([entry["name"] for entry in result["dex_entries"]],
                             ["base/dex/classes.dex", "base/dex/classes2.dex"])


if __name__ == "__main__":
    unittest.main()
