/* Source-level regression tests, not a browser/WebView rendering test. */
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const assets=path.resolve(__dirname,'../app/src/main/assets');
const html=fs.readFileSync(path.join(assets,'index.html'),'utf8');
const scripts=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]);
scripts.forEach((s,i)=>new vm.Script(s,{filename:'inline-'+i+'.js'}));
new vm.Script(fs.readFileSync(path.join(assets,'reader-host.js'),'utf8'));
function fixture(){
 const listeners={},p={innerHTML:'',setAttribute(){},removeAttribute(){},classList:{add(){},remove(){}},focus(){},offsetWidth:100};
 const document={readyState:'loading',addEventListener(k,f){(listeners[k]??=[]).push(f)},getElementById(id){return id==='bookPage'?p:null},body:{classList:{contains(){return true},add(){},remove(){}},style:{}},documentElement:{}};
 const ctx=vm.createContext({console:{error(){}},Map,Number,JSON,document,window:{scrollTo(){},addEventListener(){},matchMedia(){return{matches:true}}},localStorage:{setItem(){},getItem(){return null}}});
 vm.runInContext(scripts.find(s=>s.includes('let BOOK_PAGES=')),ctx);
 return{ctx,listeners,p};
}
const target=(id,action)=>({id,closest(selector){return selector==='#'+id||(action&&selector==='[data-action="start-reading"]')?this:null}});
async function tests(){
 const a=fixture(),nav=[];a.ctx.record=i=>nav.push(i);
 vm.runInContext("BOOK_CATALOG=[{key:'cover'},{key:'front-1'}]; showBookPage=record;",a.ctx);
 a.listeners.click.forEach(f=>f({target:target('reader_0_1_coverStart',true)}));
 await new Promise(resolve=>setImmediate(resolve));assert.deepEqual(nav,[1]);
 let prevented=false;
 a.listeners.keydown.forEach(f=>f({key:'ArrowRight',target:{closest(){return {tagName:'INPUT'}}},preventDefault(){prevented=true}}));
 assert.equal(prevented,false);assert.equal(nav.length,1);
 assert(!scripts.some(s=>/touchend[\s\S]*preventDefault/.test(s)));
 console.log('PASS cover remapped ID, input arrows, and no cancelled toolbar touchend');
 const b=fixture();
 vm.runInContext("BOOK_CATALOG=[{key:'cover'},{key:'u1l1'}]; pageHtml=async()=>{throw Error('failure')};",b.ctx);
 await vm.runInContext('showBookPage(1)',b.ctx);assert(b.p.innerHTML.includes('retryUnitLoad'));
 const retry=[];b.ctx.record=i=>retry.push(i);vm.runInContext('showBookPage=record;',b.ctx);
 b.listeners.click.forEach(f=>f({target:target('retryUnitLoad')}));assert.deepEqual(retry,[1]);
 console.log('PASS retry requests failed destination');
 for(const failure of [true,false]){
  const c=fixture();let settle;
  c.ctx.loader=e=>e.key==='old'?new Promise((resolve,reject)=>{settle=failure?reject:resolve}):Promise.resolve('NEW PAGE');
  vm.runInContext("BOOK_CATALOG=[{key:'old'},{key:'new'}]; pageHtml=loader; sanitiseBookHtml=s=>s; initialiseRenderedPage=()=>{};",c.ctx);
  const pending=vm.runInContext('showBookPage(0)',c.ctx);
  await vm.runInContext('showBookPage(1)',c.ctx);assert(c.p.innerHTML.includes('NEW PAGE'));
  settle(failure?Error('late failure'):'OLD PAGE');await pending;assert(c.p.innerHTML.includes('NEW PAGE'));
 }
 console.log('PASS stale success and stale failure cannot overwrite newer page');
 const c=fixture();vm.runInContext("BOOK_CATALOG=[{key:'0'},{key:'1'},{key:'2'}]; pageHtml=async()=>'<p>PAGE</p>';sanitiseBookHtml=s=>s;initialiseRenderedPage=()=>{};",c.ctx);
 await Promise.all([vm.runInContext('navigateRelative(1)',c.ctx),vm.runInContext('navigateRelative(1)',c.ctx)]);
 assert.equal(vm.runInContext('bookIndex',c.ctx),2);await vm.runInContext('navigateRelative(1)',c.ctx);assert.equal(vm.runInContext('bookIndex',c.ctx),2);
 assert.equal(await vm.runInContext('showBookPage(NaN)',c.ctx),undefined);
 console.log('PASS rapid next requests and final-page bounds');
 const d=fixture();const resolvers={};
 d.ctx.fetch=file=>new Promise(resolve=>{resolvers[file]=()=>resolve({ok:true,text:async()=>file})});
 vm.runInContext('unitPageMapFromHtml=(html)=>new Map([[html,html]]);',d.ctx);
 const p1=vm.runInContext("ensureUnitLoaded(1,'one')",d.ctx),p2=vm.runInContext("ensureUnitLoaded(2,'two')",d.ctx);
 resolvers.two();resolvers.one();assert((await p1).has('one'));assert((await p2).has('two'));
 console.log('PASS overlapping unit fetches retain independent page maps');
 for(const privacy of [false,true]){
  const calls=[],callbacks=new Map();let frame=0;
  const box={getBoundingClientRect(){return{bottom:privacy?800:1200}},classList:{contains(){return false}},querySelectorAll(){return[]}};
  const context=vm.createContext({console,Number,Math,bookIndex:5,readerRenderGeneration:9,getComputedStyle(){return{paddingBottom:'24px'}},cancelAnimationFrame(id){callbacks.delete(id)},requestAnimationFrame(fn){callbacks.set(++frame,fn);return frame},document:{body:{classList:{add(){}}},documentElement:{clientWidth:360},getElementById(id){return id===(privacy?'privacyFooter':'bookPage')?box:null},addEventListener(){},querySelector(){return null}},window:{AndroidHost:{pageRendered(...args){calls.push(args)}},scrollY:0,addEventListener(){}}});
  vm.runInContext(fs.readFileSync(path.join(assets,'reader-host.js'),'utf8'),context);
  function flush(){const pending=[...callbacks.values()];callbacks.clear();pending.forEach(f=>f());}
  vm.runInContext('window.reportHostHeight();window.reportHostHeight();',context);flush();
  vm.runInContext('window.reportHostHeight();',context);flush();assert.equal(calls.length,1);
  assert.deepEqual(calls[0],privacy?[-1,826,360,0]:[5,1226,360,9]);
  vm.runInContext('window.reportHostHeight(true);window.reportHostHeight();',context);flush();assert.equal(calls.length,2);
 }
 console.log('PASS reader/Privacy bridge signature, intrinsic sizing, debounce and forced sync');
 const pages=JSON.parse(fs.readFileSync(path.join(assets,'book-catalog.json'),'utf8')).pages;
 const footer=fixture();footer.ctx.catalog=pages;vm.runInContext('BOOK_CATALOG=catalog;',footer.ctx);
 for(let i=0;i<pages.length;i++){
  const output=vm.runInContext('pageNavigation('+i+')',footer.ctx);
  assert(output.includes('class="page-next" data-page-target="'+(i===pages.length-1?0:i+1)+'"'));
  assert.equal(output.includes('class="page-previous"'),i>0);
  assert(output.includes('Page / பக்கம் '+(i+1)+' / '+pages.length));
 }
 const clicked=[];footer.ctx.record=i=>clicked.push(i);vm.runInContext('showBookPage=record;',footer.ctx);
 for(const target of ['1','80','-1','81','NaN']){
  const node={getAttribute(){return target}};
  footer.listeners.click.forEach(f=>f({target:{closest(s){return s==='[data-page-target]'?node:null}}}));
 }
 assert.deepEqual(clicked,[1,80]);
 assert(html.includes("setLang('both');")&&!html.includes('onclick="setLang('));
 assert(!html.includes('id="prevPage"')&&!html.includes('id="nextPage"'));
 const hostScript=fs.readFileSync(path.join(assets,'reader-host.js'),'utf8');
 for(const token of ['touchstart','touchmove','data-figure-scale','--figure-scale'])assert(hostScript.includes(token));
 console.log('PASS single bottom navigation and scoped figure pinch/accessible zoom controls are wired');
 console.log('PASS 81 bottom navigation destinations, first/last-page bounds, invalid targets and fixed bilingual display');
 console.log('READER TESTS PASS (Node VM only; device rendering/build not exercised)');
}
tests().catch(error=>{console.error(error);process.exitCode=1});
