#!/usr/bin/env python3
from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,re,sys

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'app/src/main/assets'
VERIFY=ROOT/'verification'
errors=[]
def ok(cond,msg):
    if not cond: errors.append(msg)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

manifest=json.loads((VERIFY/'unit-equivalence-manifest.json').read_text(encoding='utf-8'))
baseline=VERIFY/'index-v1.0.3-baseline.html'
ok(baseline.exists(),'frozen baseline missing from verification/')
if baseline.exists(): ok(sha(baseline)==manifest['baseline_index_sha256'],'baseline SHA-256 mismatch')
ok(not (ASSETS/'index-v1.0.3-baseline.html').exists(),'frozen baseline must not ship in runtime assets')
ok(not (ASSETS/'unit-equivalence-manifest.json').exists(),'equivalence manifest must not ship in runtime assets')
base_text=baseline.read_text(encoding='utf-8') if baseline.exists() else ''

class Scan(HTMLParser):
    def __init__(self): super().__init__();self.ids=[];self.lesson=0;self.mcq=0;self.classes=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs); cid=a.get('id'); cls=(a.get('class') or '').split()
        if cid:self.ids.append(cid)
        self.classes.extend(cls)
        if tag=='article' and 'lesson' in cls:self.lesson+=1
        if tag=='div' and 'mcq' in cls:self.mcq+=1

total_l=total_m=0; unit_scans={}
for u in manifest['units']:
    p=ASSETS/u['file']; ok(p.exists(),f"missing {u['file']}")
    if not p.exists(): continue
    b=p.read_bytes(); t=b.decode('utf-8')
    ok(hashlib.sha256(b).hexdigest()==u['sha256'],f"unit {u['unit']} SHA-256 drift")
    ok(t in base_text,f"unit {u['unit']} is no longer an exact baseline substring")
    sc=Scan();sc.feed(t);unit_scans[u['unit']]=sc
    ok(len(sc.ids)==len(set(sc.ids)),f"unit {u['unit']} duplicate IDs")
    ok(sc.lesson==u['lessons'],f"unit {u['unit']} lesson count drift")
    ok(sc.mcq==u['mcqs'],f"unit {u['unit']} MCQ count drift")
    total_l+=sc.lesson; total_m+=sc.mcq
ok(len(manifest['units'])==9,'unit count must remain 9')
ok(total_l==46,'lesson total must remain 46')
ok(total_m==58,'MCQ total must remain 58')

catalog=json.loads((ASSETS/'book-catalog.json').read_text(encoding='utf-8'))
pages=catalog['pages']; keys=[x['key'] for x in pages]
ok(catalog.get('version')=='1.1.2','catalog version mismatch')
ok(len(pages)==80,'catalog page count must remain 80')
ok(len(keys)==len(set(keys)),'catalog keys must be unique')
ok(sum(x['type']=='lesson' for x in pages)==46,'catalog lesson count must remain 46')
ok(sum(x['type']=='unit' for x in pages)==9,'catalog unit-opening count must remain 9')
ok(sum(x['type']=='review' for x in pages)==9,'catalog review count must remain 9')
ok(sum(x['type']=='assessment' for x in pages)==9,'catalog assessment count must remain 9')
for x in pages:
    if x.get('unitFile'):
        p=ASSETS/x['unitFile'];ok(p.exists(),f"catalog points to missing {x['unitFile']}")
    if x['type']=='lesson':
        sc=unit_scans.get(x['unit']);ok(sc is not None and x.get('sourceId') in sc.ids,f"catalog lesson {x['key']} cannot resolve sourceId")

index=(ASSETS/'index.html').read_text(encoding='utf-8')
gradle=(ROOT/'app/build.gradle').read_text(encoding='utf-8')
readme=(ROOT/'README.md').read_text(encoding='utf-8')
android_manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
ok('Environmental<br/>Sciences' not in index,'stale Environmental Sciences masthead')
ok('Environmental<br/>Studies' in index,'Environmental Studies masthead missing')
ok('Modular Book Edition v1.1.2' in index,'HTML release version mismatch')
ok('function eia()' not in index,'obsolete EIA runtime remains')
ok("document.querySelector('.progress i')" not in index,'obsolete scroll-progress runtime remains')
ok("versionName '1.1.2'" in gradle and 'versionCode 10102' in gradle,'Gradle version mismatch')
ok('versionName: `1.1.2`' in readme and 'versionCode: `10102`' in readme,'README version mismatch')
ok('android:enableOnBackInvokedCallback="true"' in android_manifest,'predictive-back opt-in missing')
ok('android.permission.INTERNET' not in android_manifest,'INTERNET permission must remain absent')

if errors:
    print('VERIFY FAILED')
    for e in errors: print(' -',e)
    sys.exit(1)
print('VERIFY PASS: immutable unit payloads, catalog resolution, version sync and release-shell invariants verified.')
