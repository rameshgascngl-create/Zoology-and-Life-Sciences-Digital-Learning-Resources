from pathlib import Path
import re
text=(Path(__file__).resolve().parents[1]/'app/build.gradle').read_text()
print('version='+re.search(r"versionName\s+'([^']+)'",text).group(1))
