# Next phase: multi-density beta acceptance

1. Confirm the complete source, rendered-layout, JVM, lint and Android build gates pass. Retain the APK, exact source ZIP, DEX report and provenance from the same CI run.
2. Install the beta on a dedicated test device/profile. Do not disable Play Protect. A debug-key signature mismatch may require a separately planned migration; uninstalling can erase local preferences.
3. Test one mdpi/hdpi-class screen and one xxhdpi/xxxhdpi screen. On each, open the cover, a short contents/appendix page, a unit opener, a long bilingual lesson, a quiz and Privacy. Confirm that the footer immediately follows the content and no large blank region can be scrolled.
4. Turn pages rapidly several times, rotate the device, return from Privacy and change system font/display size. Confirm an older height callback never stretches the current page.
5. On English and Tamil figures, test tap-to-expand, two-finger pinch, −, + and Reset. Confirm ordinary vertical page scrolling still works before, during and after figure zoom.
6. Test portrait/landscape, TalkBack, gesture navigation, three-button navigation, airplane mode, app restart and reading-position restore. Include an older supported Android/WebView and Android 15/16 if available.
7. For every issue, record the page key/title, screenshot or short recording, phone model, density/resolution, Android/WebView version, font/display scale and exact reproduction steps.
8. After device acceptance, create and back up one stable upload/release key, configure a protected signed release build, then produce the Play AAB. Review privacy/store declarations and arrange academic and Tamil terminology review before public release.
