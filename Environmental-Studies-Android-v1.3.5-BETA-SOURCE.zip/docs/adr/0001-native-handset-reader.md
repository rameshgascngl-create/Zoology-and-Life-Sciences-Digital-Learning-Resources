# ADR 0001 — Native handset reader with paired bilingual content

**Status:** Accepted  
**Release:** v1.3.1  
**Date:** 2026-09-02

## Context
Earlier releases attempted transform-based pagination, swipe page turns and HTML reader controls inside Android WebView. Real-device testing repeatedly exposed clipped controls, lost clicks, horizontal displacement and unreliable vertical scrolling. v1.3.0 moved navigation to native Android controls and vertical scrolling to a native `ScrollView`. The final v1.3.0 audit also identified stale CI verifier wiring, README version drift and a terminal Tamil-block restructuring that weakened bilingual contextual anchoring.

## Decision
1. Android handset navigation is native.
2. Vertical scrolling is owned by native `ScrollView`.
3. WebView is a local content renderer hosted from `appassets.androidplatform.net`.
4. One authoritative phone CSS layer replaces accumulated reader experiments.
5. Educational source preserves semantic English–Tamil pairing; language mode changes visibility, not source order.
6. `AndroidHost` is restricted to primitive content-height reporting only.
7. Any future bridge method requires explicit security review.
8. CI uses one canonical version-aware verifier.

## Consequences
This trades animated page turns for predictable handset behaviour and maintainability. The bridge adds a small attack surface, mitigated by API 24+, local-origin-only loading, blocked external navigation, no INTERNET permission and one primitive sizing method.
