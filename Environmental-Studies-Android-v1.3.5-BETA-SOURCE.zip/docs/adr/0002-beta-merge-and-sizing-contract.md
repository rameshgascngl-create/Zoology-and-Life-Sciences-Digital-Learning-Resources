# ADR 0002 — Beta merge and sizing contract

Status: accepted for the v1.3.3 source candidate, pending device acceptance. Date: 2026-09-03.

This supersedes ADR 0001's interleaved language-order decision. Each lesson now has an English section followed by a Tamil section, per the requested reading order. The native ScrollView architecture remains.

The only annotated interface is `AndroidHost.pageRendered(int pageIndex, double cssHeight, double cssViewportWidth, long renderGeneration)`. The JavaScript caller uses `-1` only for Privacy; book indices come from the actual catalog. Java validates numeric bounds, the active local document and monotonically increasing generation before resizing. CSS height is converted to Android pixels by the live physical-view-width/CSS-viewport-width ratio. Resize notifications alone must not reset the reader to the top.

Both HTML documents use the same sizing script. Height is measured from the intrinsic end of the displayed page or Privacy footer, not document viewport height; native CSS removes viewport-dependent minimum heights. Reports are frame-debounced and deduplicated. A forced report supports deliberate native actions.

Only the local asset origin/path is allowed. Unknown subresources fail closed. The interface is not a general command, file, network or data-access API. Adding a method requires explicit security review, updated shrinker rules and verifier tests.

Figures enlarge inline rather than in a fixed viewport-sized overlay because the WebView itself can be much taller than the visible native scrolling area. All English/Tamil figure containers use the same delegated click and keyboard behavior. Device accessibility and nested horizontal/vertical gesture testing remain necessary.

Android target 36 requires explicit system-bar/cutout spacing and modern Back integration. The historical `setDecorFitsSystemWindows(true)` approach is not treated as an Android 16 opt-out. See [Android 16 behavior changes](https://developer.android.com/about/versions/16/behavior-changes-16) and [Views inset guidance](https://developer.android.com/develop/ui/views/layout/edge-to-edge).
