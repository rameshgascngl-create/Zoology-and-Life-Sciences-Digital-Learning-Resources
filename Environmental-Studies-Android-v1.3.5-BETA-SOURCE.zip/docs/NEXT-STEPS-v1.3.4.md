# Next phase: controlled handset testing

1. Require successful source checks, rendered-layout tests and Android build before sharing the APK. Keep its matching source and provenance.
2. Install on a test device/profile. Debug builds may use different signing keys. Do not uninstall without considering local-data loss; do not disable security protections.
3. Test the cover, unit openings, long bilingual lessons, all quizzes, appendices and Privacy. Check bottom Next/Previous and last-page return to cover. No blank screen should need scrolling through.
4. Test portrait/landscape, large fonts, TalkBack, gestures and three-button navigation. Include an older supported Android/WebView and Android 15/16. Browser tests do not replace handset testing.
5. Check English followed by Tamil, Tamil figure zoom, Figures/Full page, search, quiz scoring, Privacy return and reading-position restore. Repeat in airplane mode.
6. Report page number/key, screenshot, phone/Android/WebView version and reproduction steps for each issue.
7. Arrange academic and Tamil terminology review; hashes and word-count checks do not certify content accuracy or current regulatory facts.
8. After acceptance, configure a stable release signing key, keep it private/backed up, and prepare a signed release APK/AAB. Review store/privacy declarations before publication. No production signing or Play publication is performed by this beta workflow.
