# Environmental Studies — 100% Native Android v2.0.0

This project is a controlled native reconstruction of reference APK `Environmental-Studies-v1.3.6-release(1).apk` (SHA-256 `492ae85457c315c6d58241f88abd9475b111f99d948488d15b237f86e86a375b`).

## Fixed identity
- `applicationId`: `edu.gascnagercoil.environmentalsciences`
- `versionName`: `2.0.0`
- `versionCode`: `20000`
- `minSdk`: 24
- `targetSdk`: 36
- `compileSdk`: 36
- Kotlin + Jetpack Compose / Material 3

## Native-only invariant
The Android runtime contains **no WebView, HTML, CSS or JavaScript application layer**. The legacy HTML was used only as an offline migration source. Content is stored as structured JSON in `res/raw`, and the 63 embedded SVG teaching figures were rasterized to local `drawable-nodpi` resources. The five interactive models are reimplemented in Kotlin/Compose.

## Content parity inventory
- 9 units
- 46 lessons
- 58 MCQs
- 63 local teaching figures
- 5 interactive learning models
- field/campus learning
- glossary
- legal/current-information guidance
- references
- bilingual English/Tamil content
- native Privacy Policy screen
- native reader controls: search, large text, focus mode, figure-only focus, reading progress/persistence, previous/next, print and PDF export
- original launcher icon reconstructed from the reference APK vector resources

See `MIGRATION_MANIFEST.json` for source hashes and figure provenance.

## Release blockers by design
A release build must **not** be published unless both are supplied:
1. the **original app signing key** used by the already-published package; and
2. a publicly accessible HTTPS Privacy Policy URL.

The Gradle release gate expects the original keystore through environment variables and the policy URL through `-PPRIVACY_POLICY_URL=...`. Never generate a replacement signing key for an update submission.

## Public privacy page
`site/privacy-policy.html` is a deployable static policy page. Publish it on an unrestricted HTTPS host (for example GitHub Pages), verify it in an incognito browser while logged out, then use the exact same URL in Indus and the release build property.

## Release QA
Run `tools/verify_native_release.sh <apk>` after the signed build and complete `DEVICE_QA.md`. The verifier also enforces the reference signing-certificate SHA-256. A build artifact alone is not a release pass.

See `BUILD_STATUS.md` for the exact verified/not-yet-verified boundary.
