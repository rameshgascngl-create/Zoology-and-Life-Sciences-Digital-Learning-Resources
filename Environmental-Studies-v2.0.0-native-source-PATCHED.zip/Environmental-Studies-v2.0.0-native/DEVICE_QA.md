# Environmental Studies v2.0.0 — Physical-device QA gate

Release status remains **BLOCKED** until every item below passes on the signed release built with the original signing key.

## Device dimensions
- 320×568-class small phone: portrait
- 360×640-class phone: portrait + landscape
- 393×852 / 412×915-class modern phone: portrait + landscape
- 600×960-class tablet
- 800×1280-class tablet
- Gesture navigation and three-button navigation
- Default font scale and enlarged system font scale

## Functional parity
- Launch / reopen / reading-position recovery
- Unit 1–9 navigation; all 46 lessons open
- English / தமிழ் / bilingual rendering
- Large-text toggle; no clipping at enlarged app text and enlarged system font
- Focus mode enters/exits cleanly; navigation returns after exit
- Figures-only visual focus enters/exits cleanly
- Reading progress and per-lesson reading-position recovery
- Previous/Next lesson navigation including first/last disabled states
- Search finds English and Tamil lesson content
- All 63 figures load; tap-to-enlarge works; Tamil labels render correctly
- Unit review pages open
- 58 MCQs render, select, score and review correctly
- Greenhouse forcing model
- Logistic population growth model
- Energy pyramid model
- Noise addition model
- Wastewater treatment sequence
- Field/campus learning, glossary, legal/current-information guidance and references
- Privacy Policy local screen
- Public Privacy Policy button opens the exact HTTPS URL supplied to Indus
- Native Print opens Android print UI; Save PDF writes a readable bilingual lesson PDF through the system document picker
- Android Back behavior is predictable and does not exit unexpectedly

## UI / accessibility
- No content under status/navigation bars
- No horizontal page overflow; tables scroll within their own area
- No overlapping controls
- Touch targets remain usable at smallest width
- Tamil wraps normally without clipping
- Reader is single-column on phones and two-pane on tablets
- Dark/light system theme legible
- TalkBack labels present for teaching figures and major controls

## Indus evidence video
Record 60–90 seconds on a physical Android phone: launch → Units → open lesson → bilingual switch → large-text/focus option → figure enlargement → interactive tool → MCQ → Privacy Policy → Back navigation. If time permits, briefly show Save PDF or Android Print. Do not cut out transitions that demonstrate actual functionality.
