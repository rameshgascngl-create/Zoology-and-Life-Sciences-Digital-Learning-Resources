# Environmental Studies v2.0.0 — build and migration status

Status date: 26 September 2026

## Reference identity

- Reference APK: `Environmental-Studies-v1.3.6-release(1).apk`
- Reference APK SHA-256: `492ae85457c315c6d58241f88abd9475b111f99d948488d15b237f86e86a375b`
- Package: `edu.gascnagercoil.environmentalsciences`
- Reference version: `1.3.6 / 10306`
- Reference signing certificate SHA-256: `D8:2F:A9:64:C5:2E:49:33:A9:48:3A:2E:2D:1B:AC:E7:E5:93:A0:25:D1:7E:12:13:CD:3F:44:D7:FE:9B:A2:0C`
- Certificate subject: `CN=Environmental Sciences Release, OU=Department of Zoology, O=Government Arts and Science College Nagercoil, L=Nagercoil, ST=Tamil Nadu, C=IN`

## Native target

- Version: `2.0.0 / 20000`
- minSdk 24; targetSdk 36; compileSdk 36
- Kotlin + Jetpack Compose + Material 3
- Android runtime has no browser component, HTML/CSS/JavaScript app layer, or INTERNET permission.
- Public Privacy Policy is opened through the external Android browser only when the release URL is configured.

## Source/content gates already executed

- 9 units: PASS
- 46 lessons: PASS
- 92 language sections (46 English + 46 Tamil): **100% source textual-token coverage** after excluding SVG-internal labels that are preserved inside the rasterized teaching figures.
- 58 MCQs: **exact match** for question text, Tamil/English options, option count, and answer index.
- 63 source SVG teaching figures → 63 native local PNG resources: PASS.
- Figure raster integrity check: all 63 are non-trivial images; no suspiciously small/blank raster detected.
- Tamil font/raster check: corrected; representative Tamil gradient plate visually inspected after SVG camelCase restoration.
- 5 original teaching simulations: reconstructed natively (greenhouse forcing, logistic growth, energy pyramid, noise addition, wastewater train).
- Supplemental source text (About, field/campus learning, glossary, legal/current-information guidance, references): 100% source-token coverage.
- Unit opening and review text, Units 1–9: 100% source-token coverage.
- Original launcher icon vector geometry/colours recovered from the APK and restored as native launcher/adaptive-icon resources.
- Source native-only gate: PASS.

## Reader-function parity implemented natively

Search, English/Tamil/bilingual presentation, text-size enlargement, focus mode, figures-only visual focus, reading progress, per-lesson reading-position persistence, figure tap-to-enlarge with pinch/pan, previous/next lesson controls, Android native printing, native PDF export through the Storage Access Framework, review pages, MCQs, and Back navigation are implemented without a browser runtime.

## Not yet claimed as PASS

**No signed production APK/AAB has been produced in this environment.** The container does not contain the Android SDK/Gradle dependency set needed for a trustworthy full compile, and the original private signing key plus a verified public Privacy Policy URL are not available here. Generating a new signing key would break update identity and is deliberately blocked.

The included GitHub Actions workflow performs a clean signed APK+AAB build once the original signing secrets and public Privacy Policy URL are supplied. `tools/verify_native_release.sh` then checks runtime web-asset absence, WebView absence across all DEX files, package/version, INTERNET permission absence, APK signature validity, and exact match to the v1.3.6 signing certificate SHA-256 above.

Physical-device QA and the Indus functionality video remain mandatory after the signed build.
