# Intentionally minimal. Compose/R8 rules are supplied by their libraries.
-keepattributes *Annotation*
