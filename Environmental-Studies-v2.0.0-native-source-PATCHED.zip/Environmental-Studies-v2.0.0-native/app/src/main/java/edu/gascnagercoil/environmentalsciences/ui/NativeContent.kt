package edu.gascnagercoil.environmentalsciences.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import edu.gascnagercoil.environmentalsciences.model.ContentBlock

private val highlightedKinds = setOf(
    "learning_outcome", "key_terms", "explain", "memory", "summary", "think_apply",
    "didyou", "example", "databox", "compare", "cause", "depth_extension", "safety_note",
    "examnote", "note", "authoritybox", "law_facts", "agreement_facts", "hotspot_memory"
)

@Composable
fun NativeBlock(block: ContentBlock) {
    when (block.kind) {
        "figure" -> FigureBlock(block)
        "table" -> TableBlock(block)
        else -> {
            val body: @Composable () -> Unit = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (block.title.isNotBlank() && !block.text.startsWith(block.title)) {
                        Text(block.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    }
                    if (block.text.isNotBlank()) {
                        Text(block.text, style = MaterialTheme.typography.bodyLarge)
                    } else if (block.items.isNotEmpty()) {
                        block.items.forEach { Text("• $it", style = MaterialTheme.typography.bodyLarge) }
                    }
                }
            }
            if (block.kind in highlightedKinds) {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Box(Modifier.padding(14.dp)) { body() }
                }
            } else {
                Box(Modifier.fillMaxWidth()) { body() }
            }
        }
    }
}

@Composable
private fun TableBlock(block: ContentBlock) {
    if (block.rows.isEmpty()) return
    val scroll = rememberScrollState()
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (block.title.isNotBlank()) Text(block.title, fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(scroll)) {
            Column {
                block.rows.forEachIndexed { rowIndex, row ->
                    Row {
                        row.forEach { cell ->
                            Box(
                                Modifier
                                    .widthIn(min = 150.dp, max = 240.dp)
                                    .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
                                    .padding(8.dp)
                            ) {
                                Text(cell, fontWeight = if (rowIndex == 0) FontWeight.SemiBold else FontWeight.Normal)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FigureBlock(block: ContentBlock) {
    val context = LocalContext.current
    val resId = remember(block.figure) {
        context.resources.getIdentifier(block.figure.orEmpty(), "drawable", context.packageName)
    }
    var expanded by remember { mutableStateOf(false) }
    if (resId == 0) return
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (block.title.isNotBlank()) Text(block.title, fontWeight = FontWeight.SemiBold)
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            onClick = { expanded = true }
        ) {
            Image(
                painter = painterResource(resId),
                contentDescription = block.title.ifBlank { block.caption.ifBlank { "Teaching figure" } },
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                contentScale = ContentScale.Fit
            )
        }
        if (block.caption.isNotBlank()) Text(block.caption, style = MaterialTheme.typography.bodySmall)
    }
    if (expanded) ZoomDialog(resId) { expanded = false }
}

@Composable
private fun ZoomDialog(resId: Int, dismiss: () -> Unit) {
    Dialog(onDismissRequest = dismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.9f),
            shape = RoundedCornerShape(18.dp),
            tonalElevation = 6.dp
        ) {
            var scale by remember { mutableFloatStateOf(1f) }
            var offsetX by remember { mutableFloatStateOf(0f) }
            var offsetY by remember { mutableFloatStateOf(0f) }
            Box(Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(resId),
                    contentDescription = "Enlarged teaching figure",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 5f)
                                offsetX += pan.x
                                offsetY += pan.y
                            }
                        }
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offsetX,
                            translationY = offsetY
                        )
                )
                TextButton(onClick = dismiss, modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)) {
                    Text("Close")
                }
            }
        }
    }
}
