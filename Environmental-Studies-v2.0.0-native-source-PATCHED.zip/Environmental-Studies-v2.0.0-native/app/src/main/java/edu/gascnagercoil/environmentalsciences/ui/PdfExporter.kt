package edu.gascnagercoil.environmentalsciences.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.print.PageRange
import edu.gascnagercoil.environmentalsciences.model.ContentBlock
import edu.gascnagercoil.environmentalsciences.model.LanguageMode
import edu.gascnagercoil.environmentalsciences.model.Lesson
import edu.gascnagercoil.environmentalsciences.model.UnitContent
import java.io.FileOutputStream
import java.io.OutputStream
import kotlin.math.min

/**
 * Native PDF/print renderer. It uses Android Canvas + PdfDocument only:
 * no browser engine, markup renderer, network access, or storage permission.
 */
object PdfExporter {
    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 42f

    fun exportLesson(
        context: Context,
        uri: Uri,
        unit: UnitContent,
        lesson: Lesson,
        mode: LanguageMode
    ) {
        context.contentResolver.openOutputStream(uri, "w")!!.use { output ->
            writeLesson(context, output, unit, lesson, mode)
        }
    }

    fun printLesson(
        context: Context,
        unit: UnitContent,
        lesson: Lesson,
        mode: LanguageMode
    ) {
        val name = "Environmental-Studies-U${unit.number}-${lesson.number.replace('.', '-')}"
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback,
                extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback.onLayoutCancelled()
                    return
                }
                callback.onLayoutFinished(
                    PrintDocumentInfo.Builder("$name.pdf")
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .build(),
                    true
                )
            }

            override fun onWrite(
                pages: Array<out PageRange>,
                destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback.onWriteCancelled()
                    return
                }
                runCatching {
                    FileOutputStream(destination.fileDescriptor).use { output ->
                        writeLesson(context, output, unit, lesson, mode)
                    }
                }.onSuccess {
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                }.onFailure {
                    callback.onWriteFailed(it.message ?: "Unable to render document")
                }
            }
        }
        printManager.print(name, adapter, PrintAttributes.Builder().build())
    }

    private fun writeLesson(
        context: Context,
        output: OutputStream,
        unit: UnitContent,
        lesson: Lesson,
        mode: LanguageMode
    ) {
        val document = PdfDocument()
        val normal = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.BLACK
            textSize = 12f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val heading = Paint(normal).apply {
            textSize = 18f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val subheading = Paint(normal).apply {
            textSize = 14f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val caption = Paint(normal).apply {
            textSize = 10f
            color = android.graphics.Color.DKGRAY
        }

        var pageNumber = 0
        var page: PdfDocument.Page? = null
        var y = MARGIN

        fun startPage() {
            page?.let { document.finishPage(it) }
            pageNumber += 1
            page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
            y = MARGIN
            page!!.canvas.drawText("Environmental Studies · Unit ${unit.number}", MARGIN, y, caption)
            y += 24f
        }

        fun ensureSpace(required: Float) {
            if (page == null) startPage()
            if (y + required > PAGE_HEIGHT - MARGIN) startPage()
        }

        fun drawWrapped(text: String, paint: Paint, gapAfter: Float = 6f) {
            if (text.isBlank()) return
            val maxWidth = PAGE_WIDTH - MARGIN * 2
            val lineHeight = paint.fontSpacing.coerceAtLeast(paint.textSize * 1.25f)
            text.replace("\r", "").split('\n').forEach { rawParagraph ->
                var remaining = rawParagraph.trim()
                if (remaining.isEmpty()) {
                    ensureSpace(lineHeight)
                    y += lineHeight
                    return@forEach
                }
                while (remaining.isNotEmpty()) {
                    var count = paint.breakText(remaining, true, maxWidth, null).coerceAtLeast(1)
                    if (count < remaining.length) {
                        val space = remaining.lastIndexOf(' ', count - 1)
                        if (space > 0) count = space
                    }
                    val line = remaining.substring(0, min(count, remaining.length)).trimEnd()
                    ensureSpace(lineHeight)
                    page!!.canvas.drawText(line, MARGIN, y, paint)
                    y += lineHeight
                    remaining = remaining.substring(min(count, remaining.length)).trimStart()
                }
                y += gapAfter
            }
        }

        fun drawFigure(block: ContentBlock) {
            val name = block.figure ?: return
            val resId = context.resources.getIdentifier(name, "drawable", context.packageName)
            if (resId == 0) return
            val bitmap = BitmapFactory.decodeResource(context.resources, resId) ?: return
            try {
                val maxWidth = PAGE_WIDTH - MARGIN * 2
                val maxHeight = 330f
                val scale = min(maxWidth / bitmap.width.toFloat(), maxHeight / bitmap.height.toFloat())
                val width = bitmap.width * scale
                val height = bitmap.height * scale
                ensureSpace(height + 34f)
                val left = (PAGE_WIDTH - width) / 2f
                val dst = android.graphics.RectF(left, y, left + width, y + height)
                page!!.canvas.drawBitmap(bitmap, null, dst, null)
                y += height + 8f
                if (block.caption.isNotBlank()) drawWrapped(block.caption, caption, 4f)
            } finally {
                bitmap.recycle()
            }
        }

        fun drawBlock(block: ContentBlock) {
            when (block.kind) {
                "figure" -> drawFigure(block)
                "table" -> {
                    if (block.title.isNotBlank()) drawWrapped(block.title, subheading)
                    block.rows.forEach { row -> drawWrapped(row.joinToString("  |  "), normal, 2f) }
                    y += 5f
                }
                else -> {
                    if (block.title.isNotBlank() && !block.text.startsWith(block.title)) {
                        drawWrapped(block.title, subheading)
                    }
                    if (block.text.isNotBlank()) drawWrapped(block.text, normal)
                    else block.items.forEach { drawWrapped("• $it", normal, 3f) }
                }
            }
        }

        try {
            startPage()
            drawWrapped("${lesson.number} ${lesson.titleEn}", heading, 3f)
            if (lesson.titleTa.isNotBlank()) drawWrapped(lesson.titleTa, subheading, 10f)

            if (mode != LanguageMode.TAMIL) {
                drawWrapped("English", subheading)
                lesson.english.forEach(::drawBlock)
            }
            if (mode != LanguageMode.ENGLISH) {
                drawWrapped("தமிழ்", subheading)
                lesson.tamil.forEach(::drawBlock)
            }

            page?.let { document.finishPage(it) }
            page = null
            document.writeTo(output)
        } finally {
            runCatching { page?.let { document.finishPage(it) } }
            document.close()
        }
    }
}
