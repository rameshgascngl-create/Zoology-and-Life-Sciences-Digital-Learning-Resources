package edu.gascnagercoil.environmentalsciences.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import edu.gascnagercoil.environmentalsciences.BuildConfig
import edu.gascnagercoil.environmentalsciences.data.ContentRepository
import edu.gascnagercoil.environmentalsciences.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val topRoutes = setOf("home", "units", "tools", "more")

@Composable
fun EnvironmentalStudiesApp() {
    val context = LocalContext.current
    val book = remember { ContentRepository(context).load() }
    val prefs = remember { context.getSharedPreferences("learning_state", android.content.Context.MODE_PRIVATE) }
    var route by rememberSaveable { mutableStateOf(prefs.getString("last_route", "home") ?: "home") }
    var routeBeforeSearch by rememberSaveable { mutableStateOf("home") }
    var languageName by rememberSaveable { mutableStateOf(prefs.getString("language", LanguageMode.BOTH.name) ?: LanguageMode.BOTH.name) }
    var largeText by rememberSaveable { mutableStateOf(prefs.getBoolean("large_text", false)) }
    var focusMode by rememberSaveable { mutableStateOf(false) }
    var visualFocus by rememberSaveable { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    val language = runCatching { LanguageMode.valueOf(languageName) }.getOrDefault(LanguageMode.BOTH)
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    val baseDensity = LocalDensity.current
    val adjustedDensity = remember(baseDensity.density, baseDensity.fontScale, largeText) {
        Density(baseDensity.density, baseDensity.fontScale * if (largeText) 1.12f else 1f)
    }

    LaunchedEffect(route) {
        if (route != "search") prefs.edit().putString("last_route", route).apply()
    }
    LaunchedEffect(languageName) {
        prefs.edit().putString("language", languageName).apply()
    }
    LaunchedEffect(largeText) {
        prefs.edit().putBoolean("large_text", largeText).apply()
    }

    val navigate: (String) -> Unit = { destination ->
        if (destination == "search") routeBeforeSearch = route
        route = destination
    }
    val back: () -> Unit = {
        route = when {
            route == "search" -> routeBeforeSearch
            route.startsWith("lesson:") || route.startsWith("quiz:") || route.startsWith("review:") || route.startsWith("unit:") -> "units"
            route.startsWith("supp:") || route == "privacy" -> "more"
            else -> "home"
        }
    }
    val inLesson = route.startsWith("lesson:")
    LaunchedEffect(inLesson) {
        if (!inLesson) {
            focusMode = false
            visualFocus = false
        }
    }
    BackHandler(enabled = route != "home", onBack = back)

    CompositionLocalProvider(LocalDensity provides adjustedDensity) {
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Environmental Studies", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (wide && !focusMode) Text("சுற்றுச்சூழல் ஆய்வுகள்", style = MaterialTheme.typography.labelMedium)
                        }
                    },
                    navigationIcon = {
                        if (route !in topRoutes) {
                            IconButton(onClick = back) { Text("←") }
                        }
                    },
                    actions = {
                        Box {
                            TextButton(onClick = { menuOpen = true }) { Text("⋮") }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("Search / தேடல்") },
                                    onClick = {
                                        menuOpen = false
                                        navigate("search")
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(if (largeText) "Standard text size" else "Larger text · A↕") },
                                    onClick = {
                                        largeText = !largeText
                                        menuOpen = false
                                    }
                                )
                                if (inLesson) {
                                    DropdownMenuItem(
                                        text = { Text(if (focusMode) "Exit focus mode" else "Focus mode") },
                                        onClick = {
                                            focusMode = !focusMode
                                            menuOpen = false
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(if (visualFocus) "Full lesson" else "Figures only / படங்கள்") },
                                        onClick = {
                                            visualFocus = !visualFocus
                                            menuOpen = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                )
            },
            bottomBar = {
                if (!wide && route in topRoutes && !focusMode) {
                    NavigationBar {
                        NavItem("Home", route == "home") { route = "home" }
                        NavItem("Units", route == "units") { route = "units" }
                        NavItem("Tools", route == "tools") { route = "tools" }
                        NavItem("More", route == "more") { route = "more" }
                    }
                }
            }
        ) { padding ->
            Row(Modifier.fillMaxSize().padding(padding)) {
                if (wide && !focusMode) {
                    NavigationRail {
                        Spacer(Modifier.height(16.dp))
                        RailItem("Home", route == "home") { route = "home" }
                        RailItem("Units", route == "units") { route = "units" }
                        RailItem("Tools", route == "tools") { route = "tools" }
                        RailItem("More", route == "more") { route = "more" }
                    }
                }
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    when {
                        route == "home" -> HomeScreen(book, navigate)
                        route == "units" -> UnitsScreen(book, navigate)
                        route == "tools" -> SimulationScreen()
                        route == "more" -> MoreScreen(book, navigate)
                        route == "privacy" -> PrivacyScreen(book.privacy)
                        route == "search" -> SearchScreen(book, navigate)
                        route.startsWith("unit:") -> {
                            val n = route.substringAfter(':').toIntOrNull() ?: 1
                            book.units.firstOrNull { it.number == n }?.let { UnitOpeningScreen(it, navigate) }
                        }
                        route.startsWith("lesson:") -> {
                            val parts = route.split(':')
                            val n = parts.getOrNull(1)?.toIntOrNull() ?: 1
                            val id = parts.getOrNull(2).orEmpty()
                            val unit = book.units.firstOrNull { it.number == n }
                            val lesson = unit?.lessons?.firstOrNull { it.id == id }
                            if (unit != null && lesson != null) {
                                LessonScreen(
                                    unit = unit,
                                    lesson = lesson,
                                    mode = language,
                                    onMode = { languageName = it.name },
                                    navigate = navigate,
                                    wide = wide,
                                    focusMode = focusMode,
                                    visualFocus = visualFocus
                                )
                            }
                        }
                        route.startsWith("review:") -> {
                            val n = route.substringAfter(':').toIntOrNull() ?: 1
                            book.units.firstOrNull { it.number == n }?.let { ReviewScreen(it) }
                        }
                        route.startsWith("quiz:") -> {
                            val n = route.substringAfter(':').toIntOrNull() ?: 1
                            book.units.firstOrNull { it.number == n }?.let {
                                QuizScreen(it, language, { languageName = it.name })
                            }
                        }
                        route.startsWith("supp:") -> {
                            val key = route.substringAfter(':')
                            book.supplemental.firstOrNull { it.key == key }?.let { SupplementalScreen(it) }
                        }
                        else -> HomeScreen(book, navigate)
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.NavItem(label: String, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(selected = selected, onClick = onClick, icon = { Text(label.take(1)) }, label = { Text(label) })
}

@Composable
private fun RailItem(label: String, selected: Boolean, onClick: () -> Unit) {
    NavigationRailItem(selected = selected, onClick = onClick, icon = { Text(label.take(1)) }, label = { Text(label) })
}

@Composable
private fun HomeScreen(book: Book, navigate: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(book.titleEn, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text(book.titleTa, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(6.dp))
            Text(book.subtitleEn, style = MaterialTheme.typography.titleMedium)
        }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Native Android Edition · v2.0", fontWeight = FontWeight.SemiBold)
                    Text("9 Units · 46 Lessons · 58 MCQs · English + தமிழ்")
                    Button(onClick = { navigate("unit:1") }) { Text("Start reading / படிக்கத் தொடங்குக") }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { navigate("units") }) { Text("Contents") }
                OutlinedButton(onClick = { navigate("tools") }) { Text("Interactive tools") }
            }
        }
        items(book.units) { unit ->
            ElevatedCard(Modifier.fillMaxWidth().clickable { navigate("unit:${unit.number}") }) {
                Column(Modifier.padding(16.dp)) {
                    Text("Unit ${unit.number} · ${unit.titleEn}", fontWeight = FontWeight.SemiBold)
                    if (unit.titleTa.isNotBlank()) Text(unit.titleTa, style = MaterialTheme.typography.bodyMedium)
                    Text("${unit.lessons.size} lessons · ${unit.quiz.size} MCQs", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun UnitsScreen(book: Book, navigate: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(book.units) { unit ->
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Unit ${unit.number}: ${unit.titleEn}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text(unit.titleTa)
                    unit.lessons.forEach { lesson ->
                        OutlinedCard(Modifier.fillMaxWidth().clickable { navigate("lesson:${unit.number}:${lesson.id}") }) {
                            Column(Modifier.padding(12.dp)) {
                                Text("${lesson.number} ${lesson.titleEn}", fontWeight = FontWeight.Medium)
                                Text(lesson.titleTa, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { navigate("review:${unit.number}") }) { Text("Review") }
                        TextButton(onClick = { navigate("quiz:${unit.number}") }) { Text("MCQ practice (${unit.quiz.size})") }
                    }
                }
            }
        }
    }
}

@Composable
private fun UnitOpeningScreen(unit: UnitContent, navigate: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Unit ${unit.number}", style = MaterialTheme.typography.labelLarge)
            Text(unit.titleEn, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(unit.titleTa, style = MaterialTheme.typography.titleLarge)
        }
        items(unit.opening) { NativeBlock(it) }
        item { HorizontalDivider() }
        items(unit.lessons) { lesson ->
            ListItem(
                headlineContent = { Text("${lesson.number} ${lesson.titleEn}") },
                supportingContent = { Text(lesson.titleTa) },
                modifier = Modifier.clickable { navigate("lesson:${unit.number}:${lesson.id}") }
            )
            HorizontalDivider()
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { navigate("review:${unit.number}") }) { Text("Review") }
                OutlinedButton(onClick = { navigate("quiz:${unit.number}") }) { Text("MCQs") }
            }
        }
    }
}

@Composable
private fun LessonScreen(
    unit: UnitContent,
    lesson: Lesson,
    mode: LanguageMode,
    onMode: (LanguageMode) -> Unit,
    navigate: (String) -> Unit,
    wide: Boolean,
    focusMode: Boolean,
    visualFocus: Boolean
) {
    if (wide && !focusMode) {
        Row(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.width(300.dp).fillMaxHeight(), contentPadding = PaddingValues(12.dp)) {
                items(unit.lessons) { l ->
                    val selected = l.id == lesson.id
                    Surface(
                        tonalElevation = if (selected) 4.dp else 0.dp,
                        modifier = Modifier.fillMaxWidth().clickable { navigate("lesson:${unit.number}:${l.id}") }
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Text("${l.number} ${l.titleEn}", fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                            Text(l.titleTa, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            VerticalDivider()
            key(lesson.id, mode) {
                LessonBody(unit, lesson, mode, onMode, navigate, visualFocus, Modifier.weight(1f))
            }
        }
    } else {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            key(lesson.id, mode) {
                LessonBody(
                    unit,
                    lesson,
                    mode,
                    onMode,
                    navigate,
                    visualFocus,
                    Modifier.fillMaxHeight().fillMaxWidth().widthIn(max = 900.dp)
                )
            }
        }
    }
}

@Composable
private fun LessonBody(
    unit: UnitContent,
    lesson: Lesson,
    mode: LanguageMode,
    onMode: (LanguageMode) -> Unit,
    navigate: (String) -> Unit,
    visualFocus: Boolean,
    modifier: Modifier
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("learning_state", android.content.Context.MODE_PRIVATE) }
    val scrollKey = "lesson_scroll_${unit.number}_${lesson.id}_${mode.name}"
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = prefs.getInt(scrollKey, 0).coerceAtLeast(0))
    val scope = rememberCoroutineScope()
    val progress by remember {
        derivedStateOf {
            val total = listState.layoutInfo.totalItemsCount
            if (total <= 1) 0f else (listState.firstVisibleItemIndex.toFloat() / (total - 1).toFloat()).coerceIn(0f, 1f)
        }
    }
    LaunchedEffect(lesson.id, mode, visualFocus) {
        if (visualFocus) {
            listState.scrollToItem(0)
        } else {
            val saved = prefs.getInt(scrollKey, 0).coerceAtLeast(0)
            runCatching { listState.scrollToItem(saved) }
        }
        snapshotFlow { listState.firstVisibleItemIndex }.collect { index ->
            if (!visualFocus) prefs.edit().putInt(scrollKey, index).apply()
        }
    }

    val lessonIndex = unit.lessons.indexOfFirst { it.id == lesson.id }
    val previous = unit.lessons.getOrNull(lessonIndex - 1)
    val next = unit.lessons.getOrNull(lessonIndex + 1)
    val exportName = "Environmental-Studies-U${unit.number}-${lesson.number.replace('.', '-')}.pdf"
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) {
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching { PdfExporter.exportLesson(context, uri, unit, lesson, mode) }
                }
                result
                    .onSuccess { Toast.makeText(context, "PDF saved", Toast.LENGTH_SHORT).show() }
                    .onFailure { Toast.makeText(context, "PDF export failed: ${it.message ?: "unknown error"}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    val englishBlocks = if (visualFocus) lesson.english.filter { it.kind == "figure" } else lesson.english
    val tamilBlocks = if (visualFocus) lesson.tamil.filter { it.kind == "figure" } else lesson.tamil

    Column(modifier) {
        Box(Modifier.fillMaxWidth().height(3.dp).background(MaterialTheme.colorScheme.surfaceVariant)) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(progress)
                    .background(MaterialTheme.colorScheme.primary)
            )
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("${lesson.number} ${lesson.titleEn}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(lesson.titleTa, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))
                LanguageSelector(mode, onMode)
                if (visualFocus) {
                    Spacer(Modifier.height(8.dp))
                    Text("Figure focus / படங்கள் மட்டும்", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                }
            }
            if (mode != LanguageMode.TAMIL) {
                item { SectionLabel("English") }
                items(englishBlocks) { NativeBlock(it) }
            }
            if (mode != LanguageMode.ENGLISH) {
                item { SectionLabel("தமிழ்") }
                items(tamilBlocks) { NativeBlock(it) }
            }
            if (visualFocus && englishBlocks.isEmpty() && tamilBlocks.isEmpty()) {
                item { Text("No figures in this lesson / இந்தப் பாடத்தில் படங்கள் இல்லை") }
            }
            item {
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { previous?.let { navigate("lesson:${unit.number}:${it.id}") } },
                        enabled = previous != null,
                        modifier = Modifier.weight(1f)
                    ) { Text("← Previous") }
                    Button(
                        onClick = { next?.let { navigate("lesson:${unit.number}:${it.id}") } },
                        enabled = next != null,
                        modifier = Modifier.weight(1f)
                    ) { Text("Next →") }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { PdfExporter.printLesson(context, unit, lesson, mode) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Print") }
                    OutlinedButton(
                        onClick = { pdfLauncher.launch(exportName) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Save PDF") }
                }
            }
        }
    }
}

@Composable
private fun LanguageSelector(mode: LanguageMode, onMode: (LanguageMode) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = mode == LanguageMode.BOTH, onClick = { onMode(LanguageMode.BOTH) }, label = { Text("Both") })
        FilterChip(selected = mode == LanguageMode.ENGLISH, onClick = { onMode(LanguageMode.ENGLISH) }, label = { Text("English") })
        FilterChip(selected = mode == LanguageMode.TAMIL, onClick = { onMode(LanguageMode.TAMIL) }, label = { Text("தமிழ்") })
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun ReviewScreen(unit: UnitContent) {
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Unit ${unit.number} · Review", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("அலகு ${unit.number} · மீளாய்வு", style = MaterialTheme.typography.titleMedium)
        }
        items(unit.review) { NativeBlock(it) }
    }
}

@Composable
private fun MoreScreen(book: Book, navigate: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            ElevatedCard(Modifier.fillMaxWidth().clickable { navigate("privacy") }) {
                Column(Modifier.padding(16.dp)) {
                    Text("Privacy Policy", fontWeight = FontWeight.SemiBold)
                    Text("தனியுரிமைக் கொள்கை")
                }
            }
        }
        items(book.supplemental) { section ->
            ElevatedCard(Modifier.fillMaxWidth().clickable { navigate("supp:${section.key}") }) {
                Text(section.title.ifBlank { section.key }, Modifier.padding(16.dp), fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun SupplementalScreen(section: SupplementalSection) {
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(section.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        items(section.blocks) { NativeBlock(it) }
    }
}

@Composable
private fun SearchScreen(book: Book, navigate: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val hits = remember(query) {
        val q = query.trim().lowercase()
        val terms = q.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (q.length < 2) emptyList() else book.units.flatMap { u ->
            u.lessons.filter { lesson ->
                val blocks = lesson.english + lesson.tamil
                val haystack = buildString {
                    append(lesson.titleEn).append(' ').append(lesson.titleTa).append(' ')
                    blocks.forEach { block ->
                        append(block.title).append(' ').append(block.text).append(' ').append(block.caption).append(' ')
                        block.items.forEach { append(it).append(' ') }
                        block.rows.flatten().forEach { append(it).append(' ') }
                    }
                }.lowercase()
                terms.all { haystack.contains(it) }
            }.map { u to it }
        }.take(30)
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search English / தமிழ்") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(hits) { (u, l) ->
                OutlinedCard(Modifier.fillMaxWidth().clickable { navigate("lesson:${u.number}:${l.id}") }) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${l.number} ${l.titleEn}", fontWeight = FontWeight.Medium)
                        Text(l.titleTa)
                    }
                }
            }
        }
    }
}

@Composable
private fun PrivacyScreen(policy: PrivacyPolicy) {
    val context = LocalContext.current
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Privacy Policy", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("தனியுரிமைக் கொள்கை", style = MaterialTheme.typography.titleLarge)
        }
        items(policy.english) { Text(it, style = MaterialTheme.typography.bodyLarge) }
        item { HorizontalDivider() }
        items(policy.tamil) { Text(it, style = MaterialTheme.typography.bodyLarge) }
        item {
            Text("Policy version: ${policy.version}", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
            Text(policy.credit.joinToString("\n"), style = MaterialTheme.typography.bodyMedium)
        }
        if (BuildConfig.PRIVACY_POLICY_URL.isNotBlank()) {
            item {
                Button(onClick = {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(BuildConfig.PRIVACY_POLICY_URL)))
                }) { Text("Open public Privacy Policy") }
            }
        }
    }
}
