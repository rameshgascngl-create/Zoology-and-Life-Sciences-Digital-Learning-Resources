from pathlib import Path
from bs4 import BeautifulSoup
import hashlib, json, re, sys
ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'app/src/main/assets'; V=ROOT/'verification'
M=json.loads((V/'content-revision-manifest-v1.2.4.json').read_text(encoding='utf-8'))
errs=[]
for item in M['units']:
 p=A/'units'/item['file']; b=p.read_bytes(); s=BeautifulSoup(b,'html.parser')
 if hashlib.sha256(b).hexdigest()!=item['sha256']: errs.append(f"hash {item['file']}")
 if len(b)!=item['bytes']: errs.append(f"bytes {item['file']}")
 if len(s.select('article.lesson'))!=item['lessons']: errs.append(f"lessons {item['file']}")
 if len(s.select('.mcq'))!=item['mcqs']: errs.append(f"mcqs {item['file']}")
 # bilingual MCQ requirement
 for q in s.select('.mcq'):
  if not q.select_one('p .en') or not q.select_one('p .ta') or len(q.select('label .ta'))!=4: errs.append(f"bilingual mcq {item['file']}"); break
 # one review question per lesson
 r=s.select_one('.review ol')
 if not r or len(r.find_all('li',recursive=False))!=len(s.select('article.lesson')): errs.append(f"review completeness {item['file']}")
 # balanced answer-position sanity: no 5+ MCQ unit may have all answers same
 ans=[x.get('data-answer') for x in s.select('.mcq')]
 if len(ans)>=5 and len(set(ans))==1: errs.append(f"answer-position pattern {item['file']}")
cat=json.loads((A/'book-catalog.json').read_text(encoding='utf-8'))
if cat.get('version')!='1.2.4' or len(cat.get('pages',[]))!=80: errs.append('catalog')
bg=(ROOT/'app/build.gradle').read_text()
if "versionName '1.2.4'" not in bg or 'versionCode 10204' not in bg: errs.append('gradle version')
if 'android.permission.INTERNET' in (ROOT/'app/src/main/AndroidManifest.xml').read_text(): errs.append('internet permission')
# Tamil terminology consistency gate
all_ta='\n'.join(p.read_text(encoding='utf-8') for p in sorted((A/'units').glob('unit-*.html')))
for stale in ['தகவமைப்பு','நிலத்தடி நீர் மீள்நிரப்பு','நிலத்தடி நீர் நிரப்பு','சுகாதார நிலக்குழி','வளிமண்டலம்','நீர்மண்டலம்','நிலமண்டலம்','உயிர்மண்டலம்','நிலையான வேளாண்மை','நிலையான நீர்ப் பயன்பாடு','நிலையான வளாகச் செயல் திட்டம்']:
 if stale in all_ta: errs.append(f'Tamil terminology: {stale}')
if all_ta.count('கற்றல் விளைவுகள்:')!=46: errs.append('Tamil learning outcomes')
if all_ta.count('சிந்தித்துப் பாருங்கள்:')!=46: errs.append('Tamil application prompts')
if errs:
 print('VERIFY FAIL:', '; '.join(errs)); sys.exit(1)
print('VERIFY PASS: v1.2.4 pipeline/documentation correction with verified v1.2.3 content, bilingual assessment, review completeness, hashes and release metadata verified.')
