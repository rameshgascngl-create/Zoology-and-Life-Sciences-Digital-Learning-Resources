package edu.gascnagercoil.environmentalsciences;

import static org.junit.Assert.*;
import java.nio.file.*;
import java.util.regex.*;
import org.junit.BeforeClass;
import org.junit.Test;

public class ReaderAssetRegressionTest {
  private static String html;
  @BeforeClass public static void load() throws Exception {
    html = Files.readString(Paths.get("src/main/assets/index.html"));
  }
  private static int count(String regex){Matcher m=Pattern.compile(regex).matcher(html);int n=0;while(m.find())n++;return n;}
  @Test public void preservesCurriculumStructure(){assertEquals(9,count("<section class=\\\"unit\\\""));assertEquals(46,count("<article class=\\\"lesson\\\""));assertEquals(58,count("class=\\\"mcq\\\""));}
  @Test public void v106RuntimeIsPresent(){assertTrue(html.contains("reader-runtime-v106"));assertTrue(html.contains("reader-core-v106"));assertTrue(html.contains("rebuildMeasuredPages"));assertTrue(html.contains("esMcqState"));}
  @Test public void legacyReaderImplementationRemoved(){assertEquals(1,count("window\\.collectBookPages=function"));assertFalse(html.contains("function collectBookPages(){\\n  BOOK_PAGES=[];BOOK_TITLES=[];BOOK_TYPES=[];"));}
  @Test public void renderedReaderDoesNotScrollInternally(){assertTrue(html.contains(".reader-content{flex:1 1 auto;min-height:0;overflow:hidden;"));assertFalse(html.contains(".reader-content{flex:1 1 auto;min-height:0;overflow-y:auto"));}
  @Test public void comparisonCardsAndReviewCoveragePresent(){assertTrue(html.contains("compare-card-grid"));assertTrue(html.contains("Complete lesson review coverage"));}
}
